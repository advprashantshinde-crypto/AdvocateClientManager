package com.advocate.clientmanager.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.Client
import java.io.File
import java.io.FileWriter

object CsvExporter {
    fun exportClientCases(context: Context, client: Client, cases: List<Case>): File {
        val safeName = client.name.replace(Regex("[^A-Za-z0-9]"), "_").trim('_').ifBlank { "client" }
        val file = File(context.cacheDir, "${safeName}_matters.csv")
        FileWriter(file).use { writer ->
            writer.appendLine("Client Name,Phone,Email,Address,Notes")
            writer.appendLine("\"${client.name}\",\"${client.phone}\",\"${client.email}\",\"${client.address}\",\"${client.notes}\"")
            writer.appendLine()
            writer.appendLine("Case Number,Name of Parties,District,Court,Bench,Matter Type,Opposite Party,Status,Next Hearing,Disposal Date,Filing Date,VP Date,Appearing For,Respondent No.,Fees Agreed,Expenses,Fees Paid,Balance,Notes,CINO")

            for (c in cases) {
                val balance = c.feesAgreed + c.expenses - c.feesPaid
                val row = listOf(
                    c.caseNo, c.title, c.district, c.court, c.bench, c.caseType,
                    c.oppositeParty, c.status, DateUtils.fromIso(c.nextHearing),
                    DateUtils.fromIso(c.disposalDate), DateUtils.fromIso(c.filingDate),
                    DateUtils.fromIso(c.vpDate), c.appearingText(), c.respondentNo,
                    MoneyUtils.formatCompact(c.feesAgreed), MoneyUtils.formatCompact(c.expenses),
                    MoneyUtils.formatCompact(c.feesPaid), MoneyUtils.formatCompact(balance),
                    c.notes.replace("\n", " "), c.externalCino
                ).joinToString(",") { "\"${it.replace("\"", "\"\"")}\"" }
                writer.appendLine(row)
            }
        }
        return file
    }

    fun shareCsvFile(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Client Matters CSV"))
    }
}
