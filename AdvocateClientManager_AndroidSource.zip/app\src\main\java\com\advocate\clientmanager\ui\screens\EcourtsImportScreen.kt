package com.advocate.clientmanager.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.AdvocateApp
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.Client
import com.advocate.clientmanager.data.entity.EcourtsImportState
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.CourtSection
import com.advocate.clientmanager.util.EcourtsImporter
import com.advocate.clientmanager.util.NormalizedEcourtsCase
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EcourtsImportScreen(
    navController: NavController,
    app: AdvocateApp,
    section: CourtSection
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val repo = if (section == CourtSection.HIGH_COURT) app.highCourtRepo else app.districtCourtRepo

    var importMode by remember { mutableStateOf("sync") } // "sync" or "new"
    var importedRecords by remember { mutableStateOf<List<NormalizedEcourtsCase>>(emptyList()) }
    var summaryText by remember { mutableStateOf<String?>(null) }
    var clientsList by remember { mutableStateOf<List<Client>>(emptyList()) }

    LaunchedEffect(Unit) {
        clientsList = repo.getAllClientsList()
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val content = context.contentResolver.openInputStream(uri)?.use { stream ->
                        BufferedReader(InputStreamReader(stream)).readText()
                    } ?: ""
                    val jsonList = EcourtsImporter.parseJson(content)
                    val normalized = jsonList.mapNotNull { EcourtsImporter.normalize(it) }
                    importedRecords = normalized

                    if (normalized.isEmpty()) {
                        Toast.makeText(context, "No valid case records found in file", Toast.LENGTH_LONG).show()
                    } else {
                        // Process records based on mode
                        val existingCases = repo.getAllCases()
                        val existingByCino = existingCases.filter { it.externalCino.isNotBlank() }.associateBy { it.externalCino.uppercase() }
                        val existingByNo = existingCases.filter { it.caseNo.isNotBlank() }.associateBy { it.caseNo.uppercase() }

                        var updatedCount = 0
                        var unchangedCount = 0
                        var newCount = 0

                        for (item in normalized) {
                            val matched = existingByCino[item.cino.uppercase()] ?: existingByNo[item.caseNo.uppercase()]
                            if (matched != null) {
                                if (importMode == "sync") {
                                    val newStatus = item.status.ifBlank { matched.status }
                                    val newHearing = item.nextHearing.ifBlank { matched.nextHearing }
                                    if (newStatus != matched.status || newHearing != matched.nextHearing) {
                                        repo.updateCase(matched.copy(status = newStatus, nextHearing = newHearing, externalCino = item.cino))
                                        updatedCount++
                                    } else {
                                        unchangedCount++
                                    }
                                    repo.saveEcourtsState(EcourtsImportState(item.cino, matched.id, item.rawJson))
                                }
                            } else {
                                newCount++
                            }
                        }

                        summaryText = "File Processed Successfully!\n\n" +
                                "Total records in file: ${normalized.size}\n" +
                                "Status / next date updated: $updatedCount\n" +
                                "Already up to date: $unchangedCount\n" +
                                "New matters in file: $newCount"
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Import failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "eCourts Import (${section.displayName})",
                onBack = { navController.popBackStack() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "Choose Import Mode",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Ink
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (importMode == "sync") Color(0xFFE8DFC8) else Panel
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    RadioButton(
                        selected = importMode == "sync",
                        onClick = { importMode = "sync" }
                    )
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("1. Sync status and next date only", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            "Updates status and next hearing date of existing matters in this database. Client info, parties, court and fees are NOT overwritten.",
                            fontSize = 11.sp,
                            color = Muted
                        )
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (importMode == "new") Color(0xFFE8DFC8) else Panel
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                ) {
                    RadioButton(
                        selected = importMode == "new",
                        onClick = { importMode = "new" }
                    )
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("2. Import new cases into database", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            "Leaves existing matters unchanged. Imports new matters from the file into the database.",
                            fontSize = 11.sp,
                            color = Muted
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = { filePicker.launch("*/*") },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) {
                Text("Select eCourts File (.txt / .json)")
            }

            if (summaryText != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("IMPORT RESULTS", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AccentDark)
                        Spacer(Modifier.height(6.dp))
                        Text(summaryText!!, fontSize = 12.sp, color = Ink)
                    }
                }
            }
        }
    }
}
