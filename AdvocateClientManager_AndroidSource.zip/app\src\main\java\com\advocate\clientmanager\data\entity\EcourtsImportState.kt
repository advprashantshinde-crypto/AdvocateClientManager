package com.advocate.clientmanager.data.entity

import androidx.room.*

@Entity(tableName = "ecourts_import_state", indices = [Index("case_id")])
data class EcourtsImportState(
    @PrimaryKey @ColumnInfo(name = "external_cino") val externalCino: String,
    @ColumnInfo(name = "case_id") val caseId: Long,
    @ColumnInfo(name = "source_json") val sourceJson: String,
    @ColumnInfo(name = "updated_at") val updatedAt: String = ""
)
