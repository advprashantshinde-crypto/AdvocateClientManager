package com.advocate.clientmanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Client
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.components.ConfirmDialog
import com.advocate.clientmanager.ui.theme.Accent
import com.advocate.clientmanager.ui.theme.Cream
import com.advocate.clientmanager.util.DateUtils
import kotlinx.coroutines.launch

@Composable
fun AddEditClientScreen(
    navController: NavController,
    repo: AppRepository,
    clientId: Long?
) {
    val coroutineScope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf(false) }

    val isEditing = clientId != null && clientId > 0

    LaunchedEffect(clientId) {
        if (isEditing) {
            val client = repo.getClientById(clientId!!)
            if (client != null) {
                name = client.name
                phone = client.phone
                email = client.email
                address = client.address
                notes = client.notes
            }
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = if (isEditing) "Edit Client" else "New Client",
                onBack = { navController.popBackStack() },
                actions = {
                    if (isEditing) {
                        IconButton(onClick = { showDeleteDialog = true }) {
                            Icon(Icons.Default.Delete, "Delete Client", tint = Color.White)
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    nameError = it.isBlank()
                },
                label = { Text("Client Name *") },
                isError = nameError,
                supportingText = { if (nameError) Text("Name is required") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Address") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 4
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = true
                        return@Button
                    }
                    coroutineScope.launch {
                        if (isEditing) {
                            repo.updateClient(
                                Client(
                                    id = clientId!!,
                                    name = name.trim(),
                                    phone = phone.trim(),
                                    email = email.trim(),
                                    address = address.trim(),
                                    notes = notes.trim()
                                )
                            )
                        } else {
                            repo.insertClient(
                                Client(
                                    name = name.trim(),
                                    phone = phone.trim(),
                                    email = email.trim(),
                                    address = address.trim(),
                                    notes = notes.trim(),
                                    created = DateUtils.todayIso()
                                )
                            )
                        }
                        navController.popBackStack()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) {
                Text(if (isEditing) "Save Changes" else "Create Client")
            }
        }
    }

    if (showDeleteDialog && clientId != null) {
        ConfirmDialog(
            title = "Delete Client",
            message = "Are you sure you want to delete this client and all their cases, proceedings and payment history?",
            onConfirm = {
                coroutineScope.launch {
                    repo.deleteClientsByIds(listOf(clientId))
                    showDeleteDialog = false
                    navController.popBackStack()
                }
            },
            onDismiss = { showDeleteDialog = false }
        )
    }
}
