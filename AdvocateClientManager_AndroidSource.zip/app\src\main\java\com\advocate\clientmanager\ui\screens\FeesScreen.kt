package com.advocate.clientmanager.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.Client
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.navigation.Screen
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.MoneyUtils
import kotlinx.coroutines.launch
import java.net.URLEncoder

@Composable
fun FeesScreen(
    navController: NavController,
    repo: AppRepository,
    clientId: Long
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var client by remember { mutableStateOf<Client?>(null) }
    val cases by repo.getCasesForClient(clientId).collectAsState(initial = emptyList())

    var editingCase by remember { mutableStateOf<Case?>(null) }
    var editFeesAgreed by remember { mutableStateOf("") }
    var editExpenses by remember { mutableStateOf("") }

    LaunchedEffect(clientId) {
        client = repo.getClientById(clientId)
    }

    val totalFees = cases.sumOf { it.feesAgreed }
    val totalExpenses = cases.sumOf { it.expenses }
    val totalPaid = cases.sumOf { it.feesPaid }
    val totalRemaining = totalFees + totalExpenses - totalPaid

    Scaffold(
        topBar = {
            AppTopBar(
                title = "Fees & Expenses - ${client?.name ?: "Client"}",
                onBack = { navController.popBackStack() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
        ) {
            // Overall summary card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("TOTAL PROFESSIONAL FEES & EXPENSES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Muted)
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Total Billable", fontSize = 11.sp, color = Muted)
                            Text(MoneyUtils.format(totalFees + totalExpenses), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Received", fontSize = 11.sp, color = Muted)
                            Text(MoneyUtils.format(totalPaid), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GreenPending)
                        }
                        Column {
                            Text("Balance Due", fontSize = 11.sp, color = Muted)
                            Text(MoneyUtils.format(totalRemaining), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if (totalRemaining > 0) DangerText else GreenPending)
                        }
                    }

                    if (totalRemaining > 0 && client?.phone?.isNotBlank() == true) {
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val rawPhone = client?.phone?.replace("[^0-9]".toRegex(), "") ?: ""
                                val phone = if (rawPhone.length == 10) "91$rawPhone" else rawPhone
                                val msg = "Dear ${client?.name},\n\nThis is a polite reminder regarding pending professional fees. Outstanding balance: ${MoneyUtils.format(totalRemaining)}.\n\nKindly clear at your earliest convenience.\n\nRegards,\nAdvocate"
                                val url = "https://wa.me/$phone?text=${URLEncoder.encode(msg, "UTF-8")}"
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                try {
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    Toast.makeText(context, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) {
                            Icon(Icons.Default.Chat, "WhatsApp", modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Send WhatsApp Payment Reminder")
                        }
                    }
                }
            }

            Text(
                text = "MATTERS (${cases.size})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Muted,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cases, key = { it.id }) { c ->
                    val balance = c.feesAgreed + c.expenses - c.feesPaid
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Panel)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(c.caseNo.ifBlank { c.title.ifBlank { "Matter #${c.id}" } }, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    text = "Due: ${MoneyUtils.format(balance)}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (balance > 0) DangerText else GreenPending
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Fees: ${MoneyUtils.formatCompact(c.feesAgreed)}", fontSize = 11.sp, color = Muted)
                                Text("Exp: ${MoneyUtils.formatCompact(c.expenses)}", fontSize = 11.sp, color = Muted)
                                Text("Paid: ${MoneyUtils.formatCompact(c.feesPaid)}", fontSize = 11.sp, color = GreenPending)
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = {
                                    editingCase = c
                                    editFeesAgreed = c.feesAgreed.toString()
                                    editExpenses = c.expenses.toString()
                                }) {
                                    Text("Edit Amounts", fontSize = 11.sp)
                                }
                                Spacer(Modifier.width(4.dp))
                                Button(
                                    onClick = { navController.navigate(Screen.PaymentRegister.createRoute(c.id)) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Accent),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("Payment Register", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    // Edit Fees & Expenses Dialog
    if (editingCase != null) {
        val target = editingCase!!
        AlertDialog(
            onDismissRequest = { editingCase = null },
            title = { Text("Edit Fees & Expenses") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(target.caseNo.ifBlank { target.title }, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    OutlinedTextField(
                        value = editFeesAgreed,
                        onValueChange = { editFeesAgreed = it },
                        label = { Text("Professional Fees (Rs.)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editExpenses,
                        onValueChange = { editExpenses = it },
                        label = { Text("Expenses (Rs.)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val f = editFeesAgreed.replace(",", "").toDoubleOrNull() ?: 0.0
                    val e = editExpenses.replace(",", "").toDoubleOrNull() ?: 0.0
                    coroutineScope.launch {
                        repo.updateCase(target.copy(feesAgreed = f, expenses = e))
                        editingCase = null
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { editingCase = null }) { Text("Cancel") }
            }
        )
    }
}
