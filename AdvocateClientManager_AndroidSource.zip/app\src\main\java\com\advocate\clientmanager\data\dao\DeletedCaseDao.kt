package com.advocate.clientmanager.data.dao

import androidx.room.*
import com.advocate.clientmanager.data.entity.DeletedCase

@Dao
interface DeletedCaseDao {
    @Insert
    suspend fun insert(deletedCase: DeletedCase): Long

    @Query("SELECT * FROM deleted_cases ORDER BY id DESC")
    suspend fun getAll(): List<DeletedCase>

    @Query("DELETE FROM deleted_cases WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM deleted_cases")
    suspend fun clearAll()
}
