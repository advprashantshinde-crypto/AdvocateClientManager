package com.advocate.clientmanager.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.advocate.clientmanager.util.DateUtils
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showPicker by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text("DD-MM-YYYY") },
        modifier = modifier.fillMaxWidth(),
        trailingIcon = {
            Row {
                if (value.isNotBlank()) {
                    IconButton(onClick = { onValueChange("") }) {
                        Icon(Icons.Default.Clear, "Clear", modifier = Modifier.size(20.dp))
                    }
                }
                IconButton(onClick = { showPicker = true }) {
                    Icon(Icons.Default.CalendarToday, "Pick date", modifier = Modifier.size(20.dp))
                }
            }
        },
        singleLine = true
    )

    if (showPicker) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = try {
                val date = if (value.isNotBlank()) {
                    LocalDate.parse(DateUtils.toIso(value))
                } else LocalDate.now()
                date.toEpochDay() * 86400000L
            } catch (_: Exception) { System.currentTimeMillis() }
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { millis ->
                        val date = LocalDate.ofEpochDay(millis / 86400000L)
                        onValueChange(date.format(DateUtils.DISPLAY_FORMAT))
                    }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = state)
        }
    }
}
