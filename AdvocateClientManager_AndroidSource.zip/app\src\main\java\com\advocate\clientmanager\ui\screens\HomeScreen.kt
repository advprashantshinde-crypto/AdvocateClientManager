package com.advocate.clientmanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.ClientWithCaseCount
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.EmptyState
import com.advocate.clientmanager.ui.components.HeroBar
import com.advocate.clientmanager.ui.navigation.Screen
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.CourtSection
import com.advocate.clientmanager.util.CsvExporter
import com.advocate.clientmanager.util.DateUtils
import com.advocate.clientmanager.util.MoneyUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    repo: AppRepository,
    currentSection: CourtSection,
    onSectionChange: (CourtSection) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var searchQuery by remember { mutableStateOf("") }

    val clients by remember(searchQuery, currentSection) {
        if (searchQuery.isBlank()) repo.getAllClients()
        else repo.searchClients(searchQuery)
    }.collectAsState(initial = emptyList())

    var selectedClientId by remember(currentSection) { mutableStateOf<Long?>(null) }

    LaunchedEffect(clients) {
        if (selectedClientId == null && clients.isNotEmpty()) {
            selectedClientId = clients.first().id
        }
    }

    val selectedCases by remember(selectedClientId, currentSection) {
        selectedClientId?.let { repo.getCasesForClient(it) }
            ?: kotlinx.coroutines.flow.flowOf(emptyList())
    }.collectAsState(initial = emptyList())

    val totalFees = selectedCases.sumOf { it.feesAgreed }
    val totalExpenses = selectedCases.sumOf { it.expenses }
    val totalPaid = selectedCases.sumOf { it.feesPaid }
    val totalBalance = totalFees + totalExpenses - totalPaid

    Scaffold(
        topBar = {
            Column {
                HeroBar(
                    title = "Advocate Client Manager",
                    subtitle = "${currentSection.displayName} Clients Database"
                )
                // Court Section Selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Cream)
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = currentSection == CourtSection.HIGH_COURT,
                        onClick = { onSectionChange(CourtSection.HIGH_COURT) },
                        label = { Text("High Court") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = currentSection == CourtSection.DISTRICT_COURT,
                        onClick = { onSectionChange(CourtSection.DISTRICT_COURT) },
                        label = { Text("District Court") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                // Action Bar (Scrollable chips)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Cream)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { navController.navigate(Screen.AddClient.route) },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("New Client", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            selectedClientId?.let { cid ->
                                navController.navigate(Screen.AddCase.createRoute(cid))
                            }
                        },
                        enabled = selectedClientId != null,
                        colors = ButtonDefaults.buttonColors(containerColor = AccentDark),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.PostAdd, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("New Matter", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { navController.navigate(Screen.Hearings.route) },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Event, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Hearings", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { navController.navigate(Screen.Calendar.route) },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.CalendarMonth, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Calendar", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            selectedClientId?.let { cid ->
                                coroutineScope.launch {
                                    val client = repo.getClientById(cid)
                                    val cases = repo.getCasesForClientList(cid)
                                    if (client != null) {
                                        val file = CsvExporter.exportClientCases(context, client, cases)
                                        CsvExporter.shareCsvFile(context, file)
                                    }
                                }
                            }
                        },
                        enabled = selectedClientId != null,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Download, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Export CSV", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { navController.navigate(Screen.Settings.route) },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Settings, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Settings", fontSize = 12.sp)
                    }
                }

                // Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    placeholder = { Text("Search client name, phone, case no, party...") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, null)
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
        ) {
            if (clients.isEmpty()) {
                EmptyState(
                    message = if (searchQuery.isBlank()) "No clients found in ${currentSection.displayName}.\nTap '+ New Client' to get started."
                    else "No clients match '$searchQuery'",
                    actionLabel = if (searchQuery.isBlank()) "+ Add First Client" else null,
                    onAction = { navController.navigate(Screen.AddClient.route) }
                )
            } else {
                // Clients list (Horizontal Chips/Selector or Top Section)
                Text(
                    text = "CLIENTS (${clients.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Muted,
                    modifier = Modifier.padding(start = 12.dp, top = 6.dp, bottom = 4.dp)
                )

                // Client Selector Carousel
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (client in clients) {
                        val isSelected = client.id == selectedClientId
                        Card(
                            modifier = Modifier
                                .clickable { selectedClientId = client.id }
                                .widthIn(min = 150.dp, max = 220.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) Ink else Panel
                            ),
                            elevation = CardDefaults.cardElevation(if (isSelected) 4.dp else 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = client.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) Color.White else Ink,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (client.phone.isNotBlank()) {
                                    Text(
                                        text = client.phone,
                                        fontSize = 11.sp,
                                        color = if (isSelected) Color.LightGray else Muted
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "${client.activeCases} active case(s)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) Accent else AccentDark
                                )
                            }
                        }
                    }
                }

                Divider(Modifier.padding(vertical = 8.dp), color = Line)

                // Selected Client Header with actions
                val currentClient = clients.firstOrNull { it.id == selectedClientId }
                if (currentClient != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = currentClient.name,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Ink
                            )
                            if (currentClient.phone.isNotBlank()) {
                                Text(
                                    text = "Phone: ${currentClient.phone}",
                                    fontSize = 12.sp,
                                    color = Muted
                                )
                            }
                        }
                        Row {
                            IconButton(onClick = {
                                navController.navigate(Screen.EditClient.createRoute(currentClient.id))
                            }) {
                                Icon(Icons.Default.Edit, "Edit Client", tint = Accent)
                            }
                            IconButton(onClick = {
                                navController.navigate(Screen.Fees.createRoute(currentClient.id))
                            }) {
                                Icon(Icons.Default.AccountBalanceWallet, "Fees Register", tint = AccentDark)
                            }
                        }
                    }

                    // Financial Mini Summary Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Panel)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Fees + Exp", fontSize = 10.sp, color = Muted)
                                Text(MoneyUtils.formatCompact(totalFees + totalExpenses), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Received", fontSize = 10.sp, color = Muted)
                                Text(MoneyUtils.formatCompact(totalPaid), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GreenPending)
                            }
                            Column {
                                Text("Balance Due", fontSize = 10.sp, color = Muted)
                                Text(MoneyUtils.formatCompact(totalBalance), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (totalBalance > 0) DangerText else GreenPending)
                            }
                        }
                    }

                    // Cases list for selected client
                    Text(
                        text = "MATTERS (${selectedCases.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Muted,
                        modifier = Modifier.padding(start = 12.dp, top = 8.dp, bottom = 4.dp)
                    )

                    if (selectedCases.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("No cases for this client", color = Muted)
                                Spacer(Modifier.height(8.dp))
                                Button(
                                    onClick = { navController.navigate(Screen.AddCase.createRoute(currentClient.id)) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                                ) {
                                    Text("+ Add First Case")
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(selectedCases, key = { it.id }) { caseItem ->
                                CaseListItem(
                                    caseItem = caseItem,
                                    onClick = { navController.navigate(Screen.CaseDetail.createRoute(caseItem.id)) }
                                )
                            }
                            item { Spacer(Modifier.height(24.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CaseListItem(
    caseItem: Case,
    onClick: () -> Unit
) {
    val isDisposed = caseItem.status.equals("Disposed", true) || caseItem.status.equals("Closed", true)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = caseItem.caseNo.ifBlank { "Matter #${caseItem.id}" },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Ink,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = caseItem.status,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDisposed) RedDisposed else GreenPending
                )
            }

            if (caseItem.title.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = caseItem.title,
                    fontSize = 13.sp,
                    color = Ink,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (caseItem.benchCourtText().isNotBlank()) {
                    Text(
                        text = caseItem.benchCourtText(),
                        fontSize = 11.sp,
                        color = Muted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                }
                if (caseItem.nextHearing.isNotBlank()) {
                    Text(
                        text = "Next: ${DateUtils.fromIso(caseItem.nextHearing)}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = AccentDark
                    )
                }
            }
        }
    }
}
