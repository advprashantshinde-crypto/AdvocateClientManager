package com.advocate.clientmanager.ui.theme

import androidx.compose.ui.graphics.Color

val Cream = Color(0xFFF5F1EA)
val Panel = Color(0xFFFBF8F4)
val Ink = Color(0xFF1D1D1D)
val Muted = Color(0xFF5D5A55)
val Line = Color(0xFFD8D1C6)
val Accent = Color(0xFF8C6A40)
val AccentDark = Color(0xFF6E5433)
val DangerText = Color(0xFF7A342E)
val DangerBorder = Color(0xFFC7A9A3)
val GreenPending = Color(0xFF008000)
val RedDisposed = Color(0xFFFF0000)
val HeroBg = Color(0xFF000000)
val HeroText = Color(0xFFFFFFFF)

// Dark theme
val DarkBg = Color(0xFF1A1A1A)
val DarkPanel = Color(0xFF2D2D2D)
val DarkInk = Color(0xFFE0E0E0)
val DarkMuted = Color(0xFFA0A0A0)
val DarkLine = Color(0xFF404040)
val DarkAccent = Color(0xFFB8935F)
