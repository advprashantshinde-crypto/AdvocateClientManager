package com.advocate.clientmanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.Client
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.components.EmptyState
import com.advocate.clientmanager.ui.navigation.Screen
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.CourtSection
import com.advocate.clientmanager.util.DateUtils
import java.time.LocalDate

@Composable
fun HearingsScreen(
    navController: NavController,
    repo: AppRepository,
    section: CourtSection
) {
    var filterDays by remember { mutableStateOf(7) }
    val today = remember { LocalDate.now() }

    val fromDate = today.format(DateUtils.ISO_FORMAT)
    val toDate = remember(filterDays) {
        if (filterDays > 0) today.plusDays(filterDays.toLong()).format(DateUtils.ISO_FORMAT) else ""
    }

    val hearingsFlow = remember(filterDays) {
        if (filterDays > 0) repo.getHearingsInRange(fromDate, toDate)
        else repo.getUpcomingHearings()
    }
    val hearings by hearingsFlow.collectAsState(initial = emptyList())

    val clientMap = remember { mutableStateMapOf<Long, Client>() }

    LaunchedEffect(Unit) {
        val clients = repo.getAllClientsList()
        clients.forEach { clientMap[it.id] = it }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "Hearing Register (${section.displayName})",
                onBack = { navController.popBackStack() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
        ) {
            // Filter Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filterDays == 7,
                    onClick = { filterDays = 7 },
                    label = { Text("Next 7 Days") }
                )
                FilterChip(
                    selected = filterDays == 14,
                    onClick = { filterDays = 14 },
                    label = { Text("Next 14 Days") }
                )
                FilterChip(
                    selected = filterDays == 30,
                    onClick = { filterDays = 30 },
                    label = { Text("Next 30 Days") }
                )
                FilterChip(
                    selected = filterDays == 0,
                    onClick = { filterDays = 0 },
                    label = { Text("All Upcoming") }
                )
            }

            Text(
                text = "${hearings.size} hearing(s) found",
                fontSize = 12.sp,
                color = Muted,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            if (hearings.isEmpty()) {
                EmptyState(message = "No upcoming hearings scheduled for the selected period.")
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(hearings, key = { it.id }) { c ->
                        val clientName = clientMap[c.clientId]?.name ?: "Client #${c.clientId}"
                        HearingCard(
                            caseItem = c,
                            clientName = clientName,
                            onClick = { navController.navigate(Screen.CaseDetail.createRoute(c.id)) }
                        )
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}

@Composable
fun HearingCard(
    caseItem: Case,
    clientName: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = DateUtils.fromIso(caseItem.nextHearing),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentDark
                )
                Text(
                    text = caseItem.status,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = GreenPending
                )
            }

            Spacer(Modifier.height(4.dp))
            Text(
                text = caseItem.caseNo.ifBlank { "Matter #${caseItem.id}" },
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Ink
            )

            if (caseItem.title.isNotBlank()) {
                Text(
                    text = caseItem.title,
                    fontSize = 12.sp,
                    color = Ink,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Client: $clientName",
                    fontSize = 11.sp,
                    color = Muted
                )
                if (caseItem.benchCourtText().isNotBlank()) {
                    Text(
                        text = caseItem.benchCourtText(),
                        fontSize = 11.sp,
                        color = Muted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
