package com.advocate.clientmanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.Client
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.components.ConfirmDialog
import com.advocate.clientmanager.ui.components.DatePickerField
import com.advocate.clientmanager.ui.navigation.Screen
import com.advocate.clientmanager.ui.theme.Accent
import com.advocate.clientmanager.ui.theme.Cream
import com.advocate.clientmanager.util.Constants
import com.advocate.clientmanager.util.CourtSection
import com.advocate.clientmanager.util.DateUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditCaseScreen(
    navController: NavController,
    repo: AppRepository,
    clientId: Long,
    caseId: Long?,
    section: CourtSection
) {
    val coroutineScope = rememberCoroutineScope()
    val isEditing = caseId != null && caseId > 0

    var currentClientId by remember { mutableStateOf(clientId) }
    var caseNo by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }
    var court by remember { mutableStateOf("") }
    var caseType by remember { mutableStateOf("") }
    var oppositeParty by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Pending") }
    var nextHearing by remember { mutableStateOf("") }
    var disposalDate by remember { mutableStateOf("") }
    var filingDate by remember { mutableStateOf("") }
    var vpDate by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var bench by remember { mutableStateOf("") }
    var appearingFor by remember { mutableStateOf("") }
    var respondentNo by remember { mutableStateOf("") }
    var titleError by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    val matterTypes by repo.getAllMatterTypes().collectAsState(initial = emptyList())
    val allClients by remember { mutableStateOf(listOf<Client>()) }
    var clientList by remember { mutableStateOf(allClients) }

    LaunchedEffect(Unit) {
        clientList = repo.getAllClientsList()
    }

    LaunchedEffect(caseId) {
        if (isEditing) {
            val c = repo.getCaseById(caseId!!)
            if (c != null) {
                currentClientId = c.clientId
                caseNo = c.caseNo
                title = c.title
                district = c.district
                court = c.court
                caseType = c.caseType
                oppositeParty = c.oppositeParty
                status = c.status
                nextHearing = DateUtils.fromIso(c.nextHearing)
                disposalDate = DateUtils.fromIso(c.disposalDate)
                filingDate = DateUtils.fromIso(c.filingDate)
                vpDate = DateUtils.fromIso(c.vpDate)
                notes = c.notes
                bench = c.bench
                appearingFor = c.appearingFor
                respondentNo = c.respondentNo
            }
        }
    }

    var matterTypeExpanded by remember { mutableStateOf(false) }
    var statusExpanded by remember { mutableStateOf(false) }
    var appearingExpanded by remember { mutableStateOf(false) }
    var benchExpanded by remember { mutableStateOf(false) }
    var clientExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = if (isEditing) "Edit Matter" else "New Matter",
                onBack = { navController.popBackStack() },
                actions = {
                    if (isEditing) {
                        IconButton(onClick = { showDeleteDialog = true }) {
                            Icon(Icons.Default.Delete, "Delete Case", tint = Color.White)
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Client selector if editing
            if (isEditing && clientList.isNotEmpty()) {
                val currentClientName = clientList.firstOrNull { it.id == currentClientId }?.name ?: "Client"
                ExposedDropdownMenuBox(
                    expanded = clientExpanded,
                    onExpandedChange = { clientExpanded = !clientExpanded }
                ) {
                    OutlinedTextField(
                        value = currentClientName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Client / Matter Owner") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = clientExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = clientExpanded,
                        onDismissRequest = { clientExpanded = false }
                    ) {
                        clientList.forEach { c ->
                            DropdownMenuItem(
                                text = { Text("${c.name} (ID ${c.id})") },
                                onClick = {
                                    currentClientId = c.id
                                    clientExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Matter Type Dropdown
            ExposedDropdownMenuBox(
                expanded = matterTypeExpanded,
                onExpandedChange = { matterTypeExpanded = !matterTypeExpanded }
            ) {
                OutlinedTextField(
                    value = caseType,
                    onValueChange = { caseType = it },
                    label = { Text("Matter Type") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = matterTypeExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = matterTypeExpanded,
                    onDismissRequest = { matterTypeExpanded = false }
                ) {
                    val types = if (matterTypes.isNotEmpty()) matterTypes.map { it.name }
                    else if (section == CourtSection.HIGH_COURT) Constants.HIGH_COURT_MATTER_TYPES
                    else Constants.DISTRICT_COURT_MATTER_TYPES

                    types.forEach { typeName ->
                        DropdownMenuItem(
                            text = { Text(typeName) },
                            onClick = {
                                caseType = typeName
                                matterTypeExpanded = false
                            }
                        )
                    }
                }
            }

            // Case Number
            OutlinedTextField(
                value = caseNo,
                onValueChange = { caseNo = it },
                label = { Text("Case Number (e.g. WP/1234/2025)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Name of Party / Title
            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    titleError = it.isBlank()
                },
                label = { Text("Name of Party / Title *") },
                isError = titleError,
                supportingText = { if (titleError) Text("Title is required") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // Hearing & Disposal Dates
            DatePickerField(label = "Next Hearing Date", value = nextHearing, onValueChange = { nextHearing = it })
            DatePickerField(label = "Date of Disposal", value = disposalDate, onValueChange = { disposalDate = it })

            // Status Dropdown
            ExposedDropdownMenuBox(
                expanded = statusExpanded,
                onExpandedChange = { statusExpanded = !statusExpanded }
            ) {
                OutlinedTextField(
                    value = status,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Status") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = statusExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = statusExpanded,
                    onDismissRequest = { statusExpanded = false }
                ) {
                    Constants.CASE_STATUSES.forEach { s ->
                        DropdownMenuItem(
                            text = { Text(s) },
                            onClick = {
                                status = s
                                statusExpanded = false
                            }
                        )
                    }
                }
            }

            // Bench Dropdown / Custom
            ExposedDropdownMenuBox(
                expanded = benchExpanded,
                onExpandedChange = { benchExpanded = !benchExpanded }
            ) {
                OutlinedTextField(
                    value = bench,
                    onValueChange = { bench = it },
                    label = { Text("Bench / Court Name") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = benchExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = benchExpanded,
                    onDismissRequest = { benchExpanded = false }
                ) {
                    Constants.BENCHES.forEach { b ->
                        DropdownMenuItem(
                            text = { Text(b) },
                            onClick = {
                                bench = b
                                benchExpanded = false
                            }
                        )
                    }
                }
            }

            // Appearing For
            ExposedDropdownMenuBox(
                expanded = appearingExpanded,
                onExpandedChange = { appearingExpanded = !appearingExpanded }
            ) {
                OutlinedTextField(
                    value = appearingFor,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Appearing For") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = appearingExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = appearingExpanded,
                    onDismissRequest = { appearingExpanded = false }
                ) {
                    Constants.APPEARING_FOR.forEach { opt ->
                        DropdownMenuItem(
                            text = { Text(opt.ifBlank { "— Select —" }) },
                            onClick = {
                                appearingFor = opt
                                appearingExpanded = false
                            }
                        )
                    }
                }
            }

            if (appearingFor.equals("Respondent", ignoreCase = true)) {
                OutlinedTextField(
                    value = respondentNo,
                    onValueChange = { respondentNo = it },
                    label = { Text("Respondent No. (e.g. 1, 2 to 5)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            DatePickerField(label = "Date of Filing Matter", value = filingDate, onValueChange = { filingDate = it })
            DatePickerField(label = "Date of Filing VP", value = vpDate, onValueChange = { vpDate = it })

            OutlinedTextField(
                value = district,
                onValueChange = { district = it },
                label = { Text("District") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = court,
                onValueChange = { court = it },
                label = { Text("Court") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = oppositeParty,
                onValueChange = { oppositeParty = it },
                label = { Text("Opposite Party") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Subject Matter / Act / Section") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 6
            )

            Spacer(Modifier.height(8.dp))

            if (isEditing) {
                OutlinedButton(
                    onClick = { navController.navigate(Screen.Proceedings.createRoute(caseId!!)) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Proceedings / Stage Register")
                }
            }

            Button(
                onClick = {
                    if (title.isBlank()) {
                        titleError = true
                        return@Button
                    }
                    coroutineScope.launch {
                        val c = Case(
                            id = if (isEditing) caseId!! else 0,
                            clientId = currentClientId,
                            caseNo = caseNo.trim(),
                            title = title.trim(),
                            district = district.trim(),
                            court = court.trim(),
                            caseType = caseType.trim(),
                            oppositeParty = oppositeParty.trim(),
                            status = status,
                            nextHearing = DateUtils.toIso(nextHearing),
                            disposalDate = DateUtils.toIso(disposalDate),
                            filingDate = DateUtils.toIso(filingDate),
                            vpDate = DateUtils.toIso(vpDate),
                            notes = notes.trim(),
                            bench = bench.trim(),
                            appearingFor = appearingFor,
                            respondentNo = if (appearingFor.equals("Respondent", true)) respondentNo.trim() else ""
                        )
                        if (isEditing) {
                            repo.updateCase(c)
                        } else {
                            repo.insertCase(c)
                        }
                        navController.popBackStack()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) {
                Text(if (isEditing) "Save Changes" else "Add Matter")
            }
        }
    }

    if (showDeleteDialog && caseId != null) {
        ConfirmDialog(
            title = "Delete Case",
            message = "Are you sure you want to delete this case and its payment/proceeding history?",
            onConfirm = {
                coroutineScope.launch {
                    repo.deleteCaseById(caseId)
                    showDeleteDialog = false
                    navController.popBackStack()
                }
            },
            onDismiss = { showDeleteDialog = false }
        )
    }
}
