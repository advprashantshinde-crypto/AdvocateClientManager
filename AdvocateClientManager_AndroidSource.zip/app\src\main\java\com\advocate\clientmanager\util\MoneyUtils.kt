package com.advocate.clientmanager.util

import java.text.NumberFormat
import java.util.Locale

object MoneyUtils {
    private val formatter = NumberFormat.getNumberInstance(Locale("en", "IN")).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }
    private val compactFormatter = NumberFormat.getNumberInstance(Locale("en", "IN")).apply {
        minimumFractionDigits = 0
        maximumFractionDigits = 2
    }

    fun format(value: Double): String = "Rs. ${formatter.format(value)}"
    fun formatCompact(value: Double): String {
        val formatted = compactFormatter.format(value)
        return if (formatted.endsWith(".00")) formatted.dropLast(3) else formatted
    }
}
