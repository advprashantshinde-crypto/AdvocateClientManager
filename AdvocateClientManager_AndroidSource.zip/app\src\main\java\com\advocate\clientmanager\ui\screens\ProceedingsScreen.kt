package com.advocate.clientmanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.CaseProceeding
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.components.ConfirmDialog
import com.advocate.clientmanager.ui.components.DatePickerField
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.Constants
import com.advocate.clientmanager.util.CourtSection
import com.advocate.clientmanager.util.DateUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProceedingsScreen(
    navController: NavController,
    repo: AppRepository,
    caseId: Long,
    section: CourtSection
) {
    val coroutineScope = rememberCoroutineScope()
    var caseItem by remember { mutableStateOf<Case?>(null) }
    val proceedings by repo.getProceedingsForCase(caseId).collectAsState(initial = emptyList())

    val stages = remember(section) {
        if (section == CourtSection.HIGH_COURT) Constants.HIGH_COURT_PROCEEDING_STAGES
        else Constants.DISTRICT_PROCEEDING_STAGES
    }

    var dateInput by remember { mutableStateOf(DateUtils.todayDisplay()) }
    var stageInput by remember { mutableStateOf(stages.first()) }
    var remarksInput by remember { mutableStateOf("") }
    var stageExpanded by remember { mutableStateOf(false) }

    var editingProceeding by remember { mutableStateOf<CaseProceeding?>(null) }
    var proceedingToDelete by remember { mutableStateOf<CaseProceeding?>(null) }

    LaunchedEffect(caseId) {
        caseItem = repo.getCaseById(caseId)
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "Proceedings / Stage Register",
                onBack = { navController.popBackStack() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
        ) {
            // Case Title
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = caseItem?.caseNo?.ifBlank { "Matter #${caseId}" } ?: "Matter",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    if (caseItem?.title?.isNotBlank() == true) {
                        Text(caseItem!!.title, fontSize = 12.sp, color = Muted, maxLines = 1)
                    }
                }
            }

            // Entry Form
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (editingProceeding == null) "ADD PROCEEDING ENTRY" else "EDIT PROCEEDING ENTRY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentDark
                    )

                    DatePickerField(
                        label = "Proceeding Date",
                        value = dateInput,
                        onValueChange = { dateInput = it }
                    )

                    ExposedDropdownMenuBox(
                        expanded = stageExpanded,
                        onExpandedChange = { stageExpanded = !stageExpanded }
                    ) {
                        OutlinedTextField(
                            value = stageInput,
                            onValueChange = { stageInput = it },
                            label = { Text("Stage / Purpose") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = stageExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = stageExpanded,
                            onDismissRequest = { stageExpanded = false }
                        ) {
                            stages.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s) },
                                    onClick = {
                                        stageInput = s
                                        stageExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = remarksInput,
                        onValueChange = { remarksInput = it },
                        label = { Text("Details / Next Action / Remarks") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (editingProceeding != null) {
                            OutlinedButton(
                                onClick = {
                                    editingProceeding = null
                                    dateInput = DateUtils.todayDisplay()
                                    stageInput = stages.first()
                                    remarksInput = ""
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Cancel")
                            }
                        }

                        Button(
                            onClick = {
                                if (stageInput.isBlank()) return@Button
                                val dateIso = DateUtils.toIso(dateInput)
                                coroutineScope.launch {
                                    if (editingProceeding != null) {
                                        repo.updateProceeding(
                                            editingProceeding!!.copy(
                                                proceedingDate = dateIso,
                                                stage = stageInput.trim(),
                                                remarks = remarksInput.trim()
                                            )
                                        )
                                        editingProceeding = null
                                    } else {
                                        repo.insertProceeding(
                                            CaseProceeding(
                                                caseId = caseId,
                                                proceedingDate = dateIso,
                                                stage = stageInput.trim(),
                                                remarks = remarksInput.trim()
                                            )
                                        )
                                    }
                                    remarksInput = ""
                                    dateInput = DateUtils.todayDisplay()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) {
                            Text(if (editingProceeding != null) "Update" else "Save Entry")
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = "SAVED PROCEEDINGS (${proceedings.size})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Muted,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(proceedings, key = { it.id }) { p ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        colors = CardDefaults.cardColors(containerColor = Panel)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(p.stage, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(DateUtils.fromIso(p.proceedingDate), fontSize = 11.sp, color = Muted)
                                }
                                if (p.remarks.isNotBlank()) {
                                    Spacer(Modifier.height(2.dp))
                                    Text(p.remarks, fontSize = 12.sp, color = Ink)
                                }
                            }
                            Row {
                                IconButton(onClick = {
                                    editingProceeding = p
                                    dateInput = DateUtils.fromIso(p.proceedingDate)
                                    stageInput = p.stage
                                    remarksInput = p.remarks
                                }) {
                                    Icon(Icons.Default.Edit, "Edit", tint = Accent, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { proceedingToDelete = p }) {
                                    Icon(Icons.Default.Delete, "Delete", tint = DangerText, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }

    if (proceedingToDelete != null) {
        ConfirmDialog(
            title = "Delete Proceeding Entry",
            message = "Delete proceeding '${proceedingToDelete!!.stage}' of ${DateUtils.fromIso(proceedingToDelete!!.proceedingDate)}?",
            onConfirm = {
                coroutineScope.launch {
                    repo.deleteProceedingById(proceedingToDelete!!.id)
                    proceedingToDelete = null
                }
            },
            onDismiss = { proceedingToDelete = null }
        )
    }
}
