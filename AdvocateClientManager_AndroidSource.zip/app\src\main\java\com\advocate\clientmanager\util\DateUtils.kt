package com.advocate.clientmanager.util

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException

object DateUtils {
    val DISPLAY_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
    val ISO_FORMAT: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    fun toIso(displayDate: String): String {
        if (displayDate.isBlank()) return ""
        return try {
            LocalDate.parse(displayDate, DISPLAY_FORMAT).format(ISO_FORMAT)
        } catch (e: DateTimeParseException) { displayDate }
    }

    fun fromIso(isoDate: String): String {
        if (isoDate.isBlank()) return ""
        return try {
            LocalDate.parse(isoDate, ISO_FORMAT).format(DISPLAY_FORMAT)
        } catch (e: DateTimeParseException) { isoDate }
    }

    fun isValidDisplayDate(date: String): Boolean {
        if (date.isBlank()) return true
        return try { LocalDate.parse(date, DISPLAY_FORMAT); true }
        catch (e: DateTimeParseException) { false }
    }

    fun parseAnyDate(raw: String): String {
        val s = raw.trim()
        if (s.isBlank()) return ""
        val formats = listOf("dd-MM-yyyy", "dd/MM/yyyy", "dd.MM.yyyy", "yyyy-MM-dd", "d-M-yyyy", "d/M/yyyy")
        for (fmt in formats) {
            try {
                return LocalDate.parse(s, DateTimeFormatter.ofPattern(fmt)).format(ISO_FORMAT)
            } catch (_: DateTimeParseException) { }
        }
        return ""
    }

    fun todayDisplay(): String = LocalDate.now().format(DISPLAY_FORMAT)
    fun todayIso(): String = LocalDate.now().format(ISO_FORMAT)
}
