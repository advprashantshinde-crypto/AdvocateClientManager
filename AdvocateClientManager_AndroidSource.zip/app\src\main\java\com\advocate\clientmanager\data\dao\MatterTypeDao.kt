package com.advocate.clientmanager.data.dao

import androidx.room.*
import com.advocate.clientmanager.data.entity.MatterType
import kotlinx.coroutines.flow.Flow

@Dao
interface MatterTypeDao {
    @Query("SELECT * FROM matter_types ORDER BY rowid")
    fun getAllMatterTypes(): Flow<List<MatterType>>

    @Query("SELECT * FROM matter_types ORDER BY rowid")
    suspend fun getAllMatterTypesList(): List<MatterType>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(matterType: MatterType)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(types: List<MatterType>)

    @Query("DELETE FROM matter_types WHERE name = :name")
    suspend fun deleteByName(name: String)

    @Query("SELECT COUNT(*) FROM cases WHERE case_type = :typeName")
    suspend fun getUsageCount(typeName: String): Int

    @Query("DELETE FROM matter_types")
    suspend fun clearAll()
}
