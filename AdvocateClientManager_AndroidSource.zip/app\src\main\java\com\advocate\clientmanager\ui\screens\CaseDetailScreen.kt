package com.advocate.clientmanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.CaseProceeding
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.components.ConfirmDialog
import com.advocate.clientmanager.ui.navigation.Screen
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.DateUtils
import com.advocate.clientmanager.util.MoneyUtils
import kotlinx.coroutines.launch

@Composable
fun CaseDetailScreen(
    navController: NavController,
    repo: AppRepository,
    caseId: Long
) {
    val coroutineScope = rememberCoroutineScope()
    var caseItem by remember { mutableStateOf<Case?>(null) }
    var clientName by remember { mutableStateOf("") }
    var showDeleteDialog by remember { mutableStateOf(false) }

    val proceedings by repo.getProceedingsForCase(caseId).collectAsState(initial = emptyList())
    val payments by repo.getPaymentsForCase(caseId).collectAsState(initial = emptyList())

    LaunchedEffect(caseId) {
        val c = repo.getCaseById(caseId)
        caseItem = c
        if (c != null) {
            val cl = repo.getClientById(c.clientId)
            clientName = cl?.name ?: ""
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = caseItem?.caseNo?.ifBlank { "Matter Details" } ?: "Matter Details",
                onBack = { navController.popBackStack() },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.EditCase.createRoute(caseId)) }) {
                        Icon(Icons.Default.Edit, "Edit", tint = Color.White)
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, "Delete", tint = Color.White)
                    }
                }
            )
        }
    ) { paddingValues ->
        val c = caseItem
        if (c == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val isDisposed = c.status.equals("Disposed", true) || c.status.equals("Closed", true)
            val balance = c.feesAgreed + c.expenses - c.feesPaid

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(Cream)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = c.caseNo.ifBlank { "Case #${c.id}" },
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Ink
                            )
                            Text(
                                text = c.status,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDisposed) RedDisposed else GreenPending
                            )
                        }

                        if (c.title.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(c.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                        }

                        if (clientName.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text("Client: $clientName", fontSize = 12.sp, color = Muted)
                        }
                    }
                }

                // Details Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("CASE DETAILS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Muted)
                        DetailRow("Matter Type", c.caseType)
                        DetailRow("Next Hearing", DateUtils.fromIso(c.nextHearing))
                        if (c.disposalDate.isNotBlank()) DetailRow("Disposal Date", DateUtils.fromIso(c.disposalDate))
                        DetailRow("Court", c.benchCourtText())
                        DetailRow("District", c.district)
                        DetailRow("Appearing For", c.appearingText())
                        DetailRow("Opposite Party", c.oppositeParty)
                        DetailRow("Filed On", DateUtils.fromIso(c.filingDate))
                        DetailRow("VP Date", DateUtils.fromIso(c.vpDate))
                        if (c.notes.isNotBlank()) {
                            DetailRow("Subject / Section", c.notes)
                        }
                    }
                }

                // Financial Overview Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("FEES & EXPENSES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Muted)
                            Text(
                                text = "Open Payment Register >",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Accent,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Agreed Fees", fontSize = 10.sp, color = Muted)
                                Text(MoneyUtils.format(c.feesAgreed), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Expenses", fontSize = 10.sp, color = Muted)
                                Text(MoneyUtils.format(c.expenses), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Received", fontSize = 10.sp, color = Muted)
                                Text(MoneyUtils.format(c.feesPaid), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GreenPending)
                            }
                            Column {
                                Text("Balance", fontSize = 10.sp, color = Muted)
                                Text(MoneyUtils.format(balance), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (balance > 0) DangerText else GreenPending)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { navController.navigate(Screen.PaymentRegister.createRoute(caseId)) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) {
                            Text("Date-wise Payment Register (${payments.size} entries)")
                        }
                    }
                }

                // Proceedings Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("STAGE & PROCEEDINGS (${proceedings.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Muted)
                        }
                        Spacer(Modifier.height(8.dp))
                        if (proceedings.isEmpty()) {
                            Text("No proceeding entries recorded yet.", fontSize = 12.sp, color = Muted)
                        } else {
                            proceedings.take(3).forEach { p ->
                                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(p.stage, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                        Text(DateUtils.fromIso(p.proceedingDate), fontSize = 11.sp, color = Muted)
                                    }
                                    if (p.remarks.isNotBlank()) {
                                        Text(p.remarks, fontSize = 11.sp, color = Muted)
                                    }
                                    Divider(Modifier.padding(top = 4.dp), color = Line)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { navController.navigate(Screen.Proceedings.createRoute(caseId)) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Manage Proceedings / Stage History")
                        }
                    }
                }
            }
        }
    }

    if (showDeleteDialog) {
        ConfirmDialog(
            title = "Delete Case",
            message = "Are you sure you want to permanently delete this matter and all its records?",
            onConfirm = {
                coroutineScope.launch {
                    repo.deleteCaseById(caseId)
                    showDeleteDialog = false
                    navController.popBackStack()
                }
            },
            onDismiss = { showDeleteDialog = false }
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    if (value.isBlank()) return
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = Muted, modifier = Modifier.weight(1f))
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Ink, modifier = Modifier.weight(2f))
    }
}
