package com.advocate.clientmanager.data.dao

import androidx.room.*
import com.advocate.clientmanager.data.entity.CaseProceeding
import kotlinx.coroutines.flow.Flow

@Dao
interface ProceedingDao {
    @Query("SELECT * FROM case_proceedings WHERE case_id = :caseId ORDER BY proceeding_date DESC, id DESC")
    fun getProceedingsForCase(caseId: Long): Flow<List<CaseProceeding>>

    @Query("SELECT * FROM case_proceedings WHERE id = :id")
    suspend fun getProceedingById(id: Long): CaseProceeding?

    @Query("SELECT * FROM case_proceedings WHERE case_id = :caseId ORDER BY proceeding_date, id")
    suspend fun getProceedingsForCaseList(caseId: Long): List<CaseProceeding>

    @Insert
    suspend fun insert(proceeding: CaseProceeding): Long

    @Update
    suspend fun update(proceeding: CaseProceeding)

    @Query("DELETE FROM case_proceedings WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM case_proceedings WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("DELETE FROM case_proceedings")
    suspend fun clearAll()
}
