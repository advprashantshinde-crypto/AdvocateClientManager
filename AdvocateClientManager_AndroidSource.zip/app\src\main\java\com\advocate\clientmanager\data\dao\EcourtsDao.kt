package com.advocate.clientmanager.data.dao

import androidx.room.*
import com.advocate.clientmanager.data.entity.EcourtsImportState

@Dao
interface EcourtsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(state: EcourtsImportState)

    @Query("SELECT * FROM ecourts_import_state WHERE external_cino = :cino LIMIT 1")
    suspend fun getByCino(cino: String): EcourtsImportState?

    @Query("DELETE FROM ecourts_import_state")
    suspend fun clearAll()
}
