package com.advocate.clientmanager.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupManager {

    fun createBackupZip(context: Context): File {
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))
        val backupDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "Backups")
        backupDir.mkdirs()
        val zipFile = File(backupDir, "AdvocateClients_Backup_$stamp.zip")

        val dbDir = context.getDatabasePath("high_court_clients.db").parentFile ?: return zipFile

        val dbsToBackup = listOf(
            "high_court_clients.db",
            "district_court_clients.db"
        )

        ZipOutputStream(FileOutputStream(zipFile)).use { out ->
            for (dbName in dbsToBackup) {
                val dbFile = File(dbDir, dbName)
                if (dbFile.exists()) {
                    out.putNextEntry(ZipEntry(dbName))
                    FileInputStream(dbFile).use { it.copyTo(out) }
                    out.closeEntry()
                }
            }
        }
        return zipFile
    }

    fun restoreBackupZip(context: Context, zipFile: File): Boolean {
        val dbDir = context.getDatabasePath("high_court_clients.db").parentFile ?: return false
        ZipInputStream(FileInputStream(zipFile)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                if (name.endsWith(".db")) {
                    val destFile = File(dbDir, name)
                    FileOutputStream(destFile).use { fos ->
                        zis.copyTo(fos)
                    }
                }
                entry = zis.nextEntry
            }
        }
        return true
    }

    fun shareBackup(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share Database Backup"))
    }
}
