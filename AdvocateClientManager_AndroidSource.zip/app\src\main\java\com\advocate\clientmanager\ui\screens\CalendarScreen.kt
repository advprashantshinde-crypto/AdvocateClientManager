package com.advocate.clientmanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.navigation.Screen
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.CourtSection
import com.advocate.clientmanager.util.DateUtils
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun CalendarScreen(
    navController: NavController,
    repo: AppRepository,
    section: CourtSection
) {
    var currentMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var casesOnDate by remember { mutableStateOf<List<Case>>(emptyList()) }
    var monthCases by remember { mutableStateOf<List<Case>>(emptyList()) }

    // Load month cases
    LaunchedEffect(currentMonth) {
        val start = currentMonth.atDay(1).format(DateUtils.ISO_FORMAT)
        val end = currentMonth.plusMonths(1).atDay(1).format(DateUtils.ISO_FORMAT)
        monthCases = repo.getCasesInMonth(start, end)
    }

    // Load cases on selected date
    LaunchedEffect(selectedDate) {
        val dateIso = selectedDate.format(DateUtils.ISO_FORMAT)
        casesOnDate = repo.getCasesOnDate(dateIso)
    }

    // Map of date to matter count
    val dateCounts = remember(monthCases) {
        val map = mutableMapOf<LocalDate, Int>()
        for (c in monthCases) {
            val d1 = try { LocalDate.parse(c.nextHearing) } catch (_: Exception) { null }
            val d2 = try { LocalDate.parse(c.disposalDate) } catch (_: Exception) { null }
            if (d1 != null && YearMonth.from(d1) == currentMonth) map[d1] = (map[d1] ?: 0) + 1
            if (d2 != null && YearMonth.from(d2) == currentMonth && d2 != d1) map[d2] = (map[d2] ?: 0) + 1
        }
        map
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "Hearing & Disposal Calendar",
                onBack = { navController.popBackStack() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
        ) {
            // Month navigation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { currentMonth = currentMonth.minusMonths(1) }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Previous Month")
                }
                Text(
                    text = "${currentMonth.month.getDisplayName(TextStyle.FULL, Locale.ENGLISH)} ${currentMonth.year}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Ink
                )
                Row {
                    TextButton(onClick = {
                        val now = LocalDate.now()
                        currentMonth = YearMonth.now()
                        selectedDate = now
                    }) {
                        Text("Today")
                    }
                    IconButton(onClick = { currentMonth = currentMonth.plusMonths(1) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, "Next Month")
                    }
                }
            }

            // Weekday headers
            val daysOfWeek = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                for (dow in daysOfWeek) {
                    Text(
                        text = dow,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Muted
                    )
                }
            }

            Spacer(Modifier.height(4.dp))

            // Calendar grid
            val firstDayOfMonth = currentMonth.atDay(1)
            val firstDayOfWeek = firstDayOfMonth.dayOfWeek.value % 7 // Sunday = 0
            val daysInMonth = currentMonth.lengthOfMonth()
            val totalCells = 42

            LazyVerticalGrid(
                columns = GridCells.Fixed(7),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
                    .height(260.dp),
                userScrollEnabled = false
            ) {
                items(totalCells) { index ->
                    val dayNum = index - firstDayOfWeek + 1
                    if (dayNum in 1..daysInMonth) {
                        val date = currentMonth.atDay(dayNum)
                        val count = dateCounts[date] ?: 0
                        val isSelected = date == selectedDate
                        val isToday = date == LocalDate.now()

                        Box(
                            modifier = Modifier
                                .aspectRatio(1.2f)
                                .padding(2.dp)
                                .background(
                                    color = when {
                                        isSelected -> Accent
                                        count > 0 -> Color(0xFFE8DFC8)
                                        isToday -> Color(0xFFE2E2E2)
                                        else -> Panel
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .clickable { selectedDate = date },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "$dayNum",
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected || isToday) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Ink
                                )
                                if (count > 0) {
                                    Text(
                                        text = "$count",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else AccentDark
                                    )
                                }
                            }
                        }
                    } else {
                        Spacer(Modifier.aspectRatio(1.2f))
                    }
                }
            }

            Divider(color = Line, modifier = Modifier.padding(vertical = 4.dp))

            // Selected date details
            Text(
                text = "Matters on ${selectedDate.format(DateUtils.DISPLAY_FORMAT)} (${casesOnDate.size})",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Ink,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )

            if (casesOnDate.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No matters scheduled for this date", fontSize = 13.sp, color = Muted)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(casesOnDate, key = { it.id }) { c ->
                        val eventType = if (c.nextHearing == selectedDate.format(DateUtils.ISO_FORMAT)) "Hearing" else "Disposal"
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { navController.navigate(Screen.CaseDetail.createRoute(c.id)) },
                            colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(c.caseNo.ifBlank { "Matter #${c.id}" }, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(eventType, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, color = AccentDark)
                                }
                                if (c.title.isNotBlank()) {
                                    Text(c.title, fontSize = 12.sp, color = Ink, maxLines = 1)
                                }
                                if (c.court.isNotBlank()) {
                                    Text(c.court, fontSize = 11.sp, color = Muted)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
