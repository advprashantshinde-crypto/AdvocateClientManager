package com.advocate.clientmanager.data.entity

import androidx.room.*

@Entity(tableName = "deleted_cases")
data class DeletedCase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "external_cino") val externalCino: String? = null,
    @ColumnInfo(name = "case_no") val caseNo: String = "",
    val title: String = "",
    @ColumnInfo(name = "client_name") val clientName: String = "",
    @ColumnInfo(name = "deleted_at") val deletedAt: String = ""
)
