package com.advocate.clientmanager.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.MatterType
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.components.ConfirmDialog
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.CourtSection
import kotlinx.coroutines.launch

@Composable
fun MatterTypesScreen(
    navController: NavController,
    repo: AppRepository,
    section: CourtSection
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val matterTypes by repo.getAllMatterTypes().collectAsState(initial = emptyList())
    var newTypeInput by remember { mutableStateOf("") }
    var typeToDelete by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "Matter Types - ${section.displayName}",
                onBack = { navController.popBackStack() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
                .padding(16.dp)
        ) {
            // Add new type row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newTypeInput,
                    onValueChange = { newTypeInput = it },
                    label = { Text("New Matter Type") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                Button(
                    onClick = {
                        val name = newTypeInput.trim()
                        if (name.isNotBlank()) {
                            coroutineScope.launch {
                                repo.insertMatterType(MatterType(name))
                                newTypeInput = ""
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(4.dp))
                    Text("Add")
                }
            }

            Spacer(Modifier.height(16.dp))

            Text("${matterTypes.size} matter type(s) configured", fontSize = 12.sp, color = Muted)

            Spacer(Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(matterTypes, key = { it.name }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        colors = CardDefaults.cardColors(containerColor = Panel)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(item.name, fontSize = 13.sp, color = Ink)
                            IconButton(onClick = { typeToDelete = item.name }) {
                                Icon(Icons.Default.Delete, "Delete", tint = DangerText, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    if (typeToDelete != null) {
        val target = typeToDelete!!
        ConfirmDialog(
            title = "Delete Matter Type",
            message = "Remove '$target' from matter types?",
            onConfirm = {
                coroutineScope.launch {
                    val used = repo.getMatterTypeUsageCount(target)
                    if (used > 0) {
                        Toast.makeText(context, "'$target' is used by $used case(s). It cannot be deleted.", Toast.LENGTH_LONG).show()
                    } else {
                        repo.deleteMatterType(target)
                    }
                    typeToDelete = null
                }
            },
            onDismiss = { typeToDelete = null }
        )
    }
}
