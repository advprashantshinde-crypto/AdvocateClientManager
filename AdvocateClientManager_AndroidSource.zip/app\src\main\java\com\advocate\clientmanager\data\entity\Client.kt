package com.advocate.clientmanager.data.entity

import androidx.room.*

@Entity(tableName = "clients")
data class Client(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val notes: String = "",
    val created: String = ""
)

data class ClientWithCaseCount(
    val id: Long,
    val name: String,
    val phone: String,
    val email: String,
    val address: String,
    val notes: String,
    @ColumnInfo(name = "active_cases") val activeCases: Int
)
