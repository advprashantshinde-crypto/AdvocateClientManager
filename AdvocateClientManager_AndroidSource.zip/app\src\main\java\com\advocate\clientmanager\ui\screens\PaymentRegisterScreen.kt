package com.advocate.clientmanager.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.data.entity.Case
import com.advocate.clientmanager.data.entity.CasePayment
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.components.ConfirmDialog
import com.advocate.clientmanager.ui.components.DatePickerField
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.DateUtils
import com.advocate.clientmanager.util.MoneyUtils
import kotlinx.coroutines.launch

@Composable
fun PaymentRegisterScreen(
    navController: NavController,
    repo: AppRepository,
    caseId: Long
) {
    val coroutineScope = rememberCoroutineScope()
    var caseItem by remember { mutableStateOf<Case?>(null) }
    val payments by repo.getPaymentsForCase(caseId).collectAsState(initial = emptyList())

    var dateInput by remember { mutableStateOf(DateUtils.todayDisplay()) }
    var amountInput by remember { mutableStateOf("") }
    var remarksInput by remember { mutableStateOf("") }

    var editingPayment by remember { mutableStateOf<CasePayment?>(null) }
    var paymentToDelete by remember { mutableStateOf<CasePayment?>(null) }

    LaunchedEffect(caseId) {
        caseItem = repo.getCaseById(caseId)
    }

    val totalPaid = payments.sumOf { it.amount }
    val totalBillable = (caseItem?.feesAgreed ?: 0.0) + (caseItem?.expenses ?: 0.0)
    val balance = totalBillable - totalPaid

    Scaffold(
        topBar = {
            AppTopBar(
                title = "Payment Register",
                onBack = { navController.popBackStack() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
        ) {
            // Case & Summary Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = caseItem?.caseNo?.ifBlank { caseItem?.title ?: "Matter" } ?: "Matter",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Ink
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total: ${MoneyUtils.format(totalBillable)}", fontSize = 11.sp, color = Muted)
                        Text("Received: ${MoneyUtils.format(totalPaid)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GreenPending)
                        Text("Balance: ${MoneyUtils.format(balance)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (balance > 0) DangerText else GreenPending)
                    }
                }
            }

            // Add / Edit Payment Entry Form
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (editingPayment == null) "ADD NEW PAYMENT" else "EDIT PAYMENT ENTRY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentDark
                    )

                    DatePickerField(
                        label = "Payment Date",
                        value = dateInput,
                        onValueChange = { dateInput = it }
                    )

                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Amount Received (Rs.) *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = remarksInput,
                        onValueChange = { remarksInput = it },
                        label = { Text("Payment Mode / Remarks") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (editingPayment != null) {
                            OutlinedButton(
                                onClick = {
                                    editingPayment = null
                                    dateInput = DateUtils.todayDisplay()
                                    amountInput = ""
                                    remarksInput = ""
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Cancel")
                            }
                        }

                        Button(
                            onClick = {
                                val amt = amountInput.replace(",", "").toDoubleOrNull()
                                if (amt == null || amt <= 0) return@Button
                                val dateIso = DateUtils.toIso(dateInput)
                                coroutineScope.launch {
                                    if (editingPayment != null) {
                                        repo.updatePayment(
                                            editingPayment!!.copy(
                                                paymentDate = dateIso,
                                                amount = amt,
                                                remarks = remarksInput.trim()
                                            )
                                        )
                                        editingPayment = null
                                    } else {
                                        repo.insertPayment(
                                            CasePayment(
                                                caseId = caseId,
                                                paymentDate = dateIso,
                                                amount = amt,
                                                remarks = remarksInput.trim()
                                            )
                                        )
                                    }
                                    repo.recalcFeesPaid(caseId)
                                    amountInput = ""
                                    remarksInput = ""
                                    dateInput = DateUtils.todayDisplay()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) {
                            Text(if (editingPayment != null) "Update" else "Save Payment")
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = "PAYMENT HISTORY (${payments.size})",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Muted,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(payments, key = { it.id }) { p ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(6.dp),
                        colors = CardDefaults.cardColors(containerColor = Panel)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = MoneyUtils.format(p.amount),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = GreenPending
                                )
                                Text(
                                    text = if (p.paymentDate == "Previously recorded") p.paymentDate else DateUtils.fromIso(p.paymentDate),
                                    fontSize = 11.sp,
                                    color = Muted
                                )
                                if (p.remarks.isNotBlank()) {
                                    Text(p.remarks, fontSize = 11.sp, color = Ink)
                                }
                            }
                            Row {
                                IconButton(onClick = {
                                    editingPayment = p
                                    dateInput = if (p.paymentDate == "Previously recorded") DateUtils.todayDisplay() else DateUtils.fromIso(p.paymentDate)
                                    amountInput = p.amount.toString()
                                    remarksInput = p.remarks
                                }) {
                                    Icon(Icons.Default.Edit, "Edit", tint = Accent, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { paymentToDelete = p }) {
                                    Icon(Icons.Default.Delete, "Delete", tint = DangerText, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(16.dp)) }
            }
        }
    }

    if (paymentToDelete != null) {
        ConfirmDialog(
            title = "Delete Payment Entry",
            message = "Delete receipt of ${MoneyUtils.format(paymentToDelete!!.amount)} dated ${DateUtils.fromIso(paymentToDelete!!.paymentDate)}?",
            onConfirm = {
                coroutineScope.launch {
                    repo.deletePaymentById(paymentToDelete!!.id)
                    repo.recalcFeesPaid(caseId)
                    paymentToDelete = null
                }
            },
            onDismiss = { paymentToDelete = null }
        )
    }
}
