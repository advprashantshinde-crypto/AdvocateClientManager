package com.advocate.clientmanager.data.dao

import androidx.room.*
import com.advocate.clientmanager.data.entity.Client
import com.advocate.clientmanager.data.entity.ClientWithCaseCount
import kotlinx.coroutines.flow.Flow

@Dao
interface ClientDao {
    @Query("""
        SELECT c.*, (SELECT COUNT(*) FROM cases k
            WHERE k.client_id = c.id AND k.status NOT IN ('Disposed','Closed')) AS active_cases
        FROM clients c ORDER BY c.name COLLATE NOCASE
    """)
    fun getAllClientsWithCaseCount(): Flow<List<ClientWithCaseCount>>

    @Query("""
        SELECT c.*, (SELECT COUNT(*) FROM cases k
            WHERE k.client_id = c.id AND k.status NOT IN ('Disposed','Closed')) AS active_cases
        FROM clients c
        WHERE c.name LIKE :query OR c.phone LIKE :query OR c.email LIKE :query
           OR c.id IN (SELECT client_id FROM cases WHERE case_no LIKE :query OR title LIKE :query OR district LIKE :query)
        ORDER BY c.name COLLATE NOCASE
    """)
    fun searchClients(query: String): Flow<List<ClientWithCaseCount>>

    @Query("SELECT * FROM clients WHERE id = :id")
    suspend fun getClientById(id: Long): Client?

    @Query("SELECT * FROM clients ORDER BY name COLLATE NOCASE")
    suspend fun getAllClientsList(): List<Client>

    @Insert
    suspend fun insert(client: Client): Long

    @Update
    suspend fun update(client: Client)

    @Delete
    suspend fun delete(client: Client)

    @Query("DELETE FROM clients WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("SELECT COUNT(*) FROM clients")
    suspend fun getCount(): Int

    @Query("DELETE FROM clients")
    suspend fun clearAll()
}
