package com.advocate.clientmanager.data.entity

import androidx.room.*

@Entity(
    tableName = "case_payments",
    foreignKeys = [ForeignKey(entity = Case::class, parentColumns = ["id"], childColumns = ["case_id"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("case_id")]
)
data class CasePayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "case_id") val caseId: Long,
    @ColumnInfo(name = "payment_date") val paymentDate: String,
    val amount: Double = 0.0,
    val remarks: String = ""
)
