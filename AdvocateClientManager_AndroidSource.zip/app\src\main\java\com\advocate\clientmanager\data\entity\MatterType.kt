package com.advocate.clientmanager.data.entity

import androidx.room.*

@Entity(tableName = "matter_types")
data class MatterType(
    @PrimaryKey val name: String
)
