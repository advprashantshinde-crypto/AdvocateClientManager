package com.advocate.clientmanager.data.dao

import androidx.room.*
import com.advocate.clientmanager.data.entity.Case
import kotlinx.coroutines.flow.Flow

@Dao
interface CaseDao {
    @Query("SELECT * FROM cases WHERE client_id = :clientId ORDER BY CASE WHEN next_hearing IS NULL OR next_hearing = '' THEN 1 ELSE 0 END, next_hearing, case_no")
    fun getCasesForClient(clientId: Long): Flow<List<Case>>

    @Query("SELECT * FROM cases WHERE id = :id")
    suspend fun getCaseById(id: Long): Case?

    @Query("""
        SELECT k.* FROM cases k JOIN clients cl ON cl.id = k.client_id
        WHERE k.next_hearing IS NOT NULL AND k.next_hearing <> ''
        AND k.next_hearing >= :fromDate
        AND COALESCE(k.status, 'Pending') NOT IN ('Disposed','Closed')
        ORDER BY k.next_hearing, k.case_no
    """)
    fun getUpcomingHearings(fromDate: String): Flow<List<Case>>

    @Query("""
        SELECT k.* FROM cases k JOIN clients cl ON cl.id = k.client_id
        WHERE k.next_hearing IS NOT NULL AND k.next_hearing <> ''
        AND k.next_hearing >= :fromDate AND k.next_hearing <= :toDate
        AND COALESCE(k.status, 'Pending') NOT IN ('Disposed','Closed')
        ORDER BY k.next_hearing, k.case_no
    """)
    fun getHearingsInRange(fromDate: String, toDate: String): Flow<List<Case>>

    @Query("""
        SELECT * FROM cases
        WHERE (next_hearing >= :start AND next_hearing < :end)
           OR (disposal_date >= :start AND disposal_date < :end)
    """)
    suspend fun getCasesInMonth(start: String, end: String): List<Case>

    @Query("""
        SELECT * FROM cases
        WHERE next_hearing = :date OR disposal_date = :date
        ORDER BY case_no
    """)
    suspend fun getCasesOnDate(date: String): List<Case>

    @Query("SELECT * FROM cases WHERE client_id = :clientId ORDER BY case_no")
    suspend fun getCasesForClientList(clientId: Long): List<Case>

    @Query("SELECT * FROM cases ORDER BY case_no")
    suspend fun getAllCases(): List<Case>

    @Query("SELECT * FROM cases WHERE external_cino = :cino LIMIT 1")
    suspend fun getCaseByCino(cino: String): Case?

    @Insert
    suspend fun insert(c: Case): Long

    @Update
    suspend fun update(c: Case)

    @Query("DELETE FROM cases WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM cases WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("UPDATE cases SET fees_paid = COALESCE((SELECT SUM(amount) FROM case_payments WHERE case_id = :caseId), 0) WHERE id = :caseId")
    suspend fun recalcFeesPaid(caseId: Long)

    @Query("DELETE FROM cases")
    suspend fun clearAll()
}
