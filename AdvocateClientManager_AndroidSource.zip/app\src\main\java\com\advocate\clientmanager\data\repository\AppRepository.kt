package com.advocate.clientmanager.data.repository

import com.advocate.clientmanager.data.AppDatabase
import com.advocate.clientmanager.data.entity.*
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class AppRepository(val db: AppDatabase) {

    // --- Clients ---
    fun getAllClients(): Flow<List<ClientWithCaseCount>> = db.clientDao().getAllClientsWithCaseCount()
    fun searchClients(query: String): Flow<List<ClientWithCaseCount>> =
        db.clientDao().searchClients("%$query%")
    suspend fun getClientById(id: Long) = db.clientDao().getClientById(id)
    suspend fun getAllClientsList() = db.clientDao().getAllClientsList()
    suspend fun insertClient(client: Client) = db.clientDao().insert(client)
    suspend fun updateClient(client: Client) = db.clientDao().update(client)
    suspend fun deleteClientsByIds(ids: List<Long>) = db.clientDao().deleteByIds(ids)
    suspend fun getClientCount() = db.clientDao().getCount()

    // --- Cases ---
    fun getCasesForClient(clientId: Long): Flow<List<Case>> = db.caseDao().getCasesForClient(clientId)
    suspend fun getCaseById(id: Long) = db.caseDao().getCaseById(id)
    suspend fun getCasesForClientList(clientId: Long) = db.caseDao().getCasesForClientList(clientId)
    suspend fun getAllCases() = db.caseDao().getAllCases()
    suspend fun insertCase(c: Case) = db.caseDao().insert(c)
    suspend fun updateCase(c: Case) = db.caseDao().update(c)
    suspend fun deleteCaseById(id: Long) = db.caseDao().deleteById(id)
    suspend fun deleteCasesByIds(ids: List<Long>) = db.caseDao().deleteByIds(ids)
    suspend fun getCaseByCino(cino: String) = db.caseDao().getCaseByCino(cino)
    suspend fun recalcFeesPaid(caseId: Long) = db.caseDao().recalcFeesPaid(caseId)

    // --- Hearings ---
    fun getUpcomingHearings(): Flow<List<Case>> =
        db.caseDao().getUpcomingHearings(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE))
    fun getHearingsInRange(from: String, to: String) = db.caseDao().getHearingsInRange(from, to)
    suspend fun getCasesInMonth(start: String, end: String) = db.caseDao().getCasesInMonth(start, end)
    suspend fun getCasesOnDate(date: String) = db.caseDao().getCasesOnDate(date)

    // --- Payments ---
    fun getPaymentsForCase(caseId: Long) = db.paymentDao().getPaymentsForCase(caseId)
    suspend fun getPaymentsForCaseList(caseId: Long) = db.paymentDao().getPaymentsForCaseList(caseId)
    suspend fun insertPayment(payment: CasePayment) = db.paymentDao().insert(payment)
    suspend fun updatePayment(payment: CasePayment) = db.paymentDao().update(payment)
    suspend fun deletePaymentById(id: Long) = db.paymentDao().deleteById(id)
    suspend fun deletePaymentsByIds(ids: List<Long>) = db.paymentDao().deleteByIds(ids)
    suspend fun deleteAllPaymentsForCase(caseId: Long) = db.paymentDao().deleteAllForCase(caseId)
    suspend fun getTotalPaid(caseId: Long) = db.paymentDao().getTotalPaid(caseId)
    suspend fun getPaymentById(id: Long) = db.paymentDao().getPaymentById(id)

    // --- Proceedings ---
    fun getProceedingsForCase(caseId: Long) = db.proceedingDao().getProceedingsForCase(caseId)
    suspend fun getProceedingsForCaseList(caseId: Long) = db.proceedingDao().getProceedingsForCaseList(caseId)
    suspend fun insertProceeding(p: CaseProceeding) = db.proceedingDao().insert(p)
    suspend fun updateProceeding(p: CaseProceeding) = db.proceedingDao().update(p)
    suspend fun deleteProceedingById(id: Long) = db.proceedingDao().deleteById(id)
    suspend fun deleteProceedingsByIds(ids: List<Long>) = db.proceedingDao().deleteByIds(ids)

    // --- Matter Types ---
    fun getAllMatterTypes() = db.matterTypeDao().getAllMatterTypes()
    suspend fun getAllMatterTypesList() = db.matterTypeDao().getAllMatterTypesList()
    suspend fun insertMatterType(type: MatterType) = db.matterTypeDao().insert(type)
    suspend fun insertAllMatterTypes(types: List<MatterType>) = db.matterTypeDao().insertAll(types)
    suspend fun deleteMatterType(name: String) = db.matterTypeDao().deleteByName(name)
    suspend fun getMatterTypeUsageCount(name: String) = db.matterTypeDao().getUsageCount(name)

    // --- Deleted Cases ---
    suspend fun insertDeletedCase(dc: DeletedCase) = db.deletedCaseDao().insert(dc)
    suspend fun getAllDeletedCases() = db.deletedCaseDao().getAll()

    // --- eCourts State ---
    suspend fun saveEcourtsState(state: EcourtsImportState) = db.ecourtsDao().insertOrUpdate(state)

    // --- Factory Reset ---
    suspend fun factoryReset(defaultMatterTypes: List<String>) {
        db.paymentDao().clearAll()
        db.proceedingDao().clearAll()
        db.deletedCaseDao().clearAll()
        db.ecourtsDao().clearAll()
        db.caseDao().clearAll()
        db.clientDao().clearAll()
        db.matterTypeDao().clearAll()
        db.matterTypeDao().insertAll(defaultMatterTypes.map { MatterType(it) })
    }
}
