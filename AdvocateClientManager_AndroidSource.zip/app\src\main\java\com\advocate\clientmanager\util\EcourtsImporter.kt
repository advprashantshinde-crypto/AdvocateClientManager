package com.advocate.clientmanager.util

import com.advocate.clientmanager.data.entity.Case
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.regex.Pattern

data class NormalizedEcourtsCase(
    val cino: String,
    val caseNo: String,
    val title: String,
    val district: String,
    val court: String,
    val caseType: String,
    val oppositeParty: String,
    val status: String,
    val nextHearing: String,
    val disposalDate: String,
    val filingDate: String,
    val vpDate: String,
    val notes: String,
    val bench: String,
    val appearingFor: String,
    val respondentNo: String,
    val rawJson: String
)

object EcourtsImporter {

    fun parseJson(raw: String): List<JSONObject> {
        val trimmed = raw.trim()
        val results = mutableListOf<JSONObject>()
        if (trimmed.startsWith("[")) {
            val arr = JSONArray(trimmed)
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i)
                if (item != null) results.add(item)
            }
        } else if (trimmed.startsWith("{")) {
            val root = JSONObject(trimmed)
            for (key in listOf("data", "cases", "myCases", "records")) {
                if (root.has(key)) {
                    val arr = root.optJSONArray(key)
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONObject(i)
                            if (item != null) results.add(item)
                        }
                        return results
                    }
                }
            }
            results.add(root)
        }
        return results
    }

    fun guessSection(records: List<JSONObject>): CourtSection {
        var highCourt = 0
        var district = 0
        for (r in records) {
            val cino = r.optString("cino").uppercase()
            val code = r.optString("establishment_code").uppercase()
            if (cino.startsWith("HCBM") || code.startsWith("HCBM")) {
                highCourt++
            } else if (cino.startsWith("MH") || code.startsWith("MH")) {
                district++
            }
        }
        return if (highCourt >= district) CourtSection.HIGH_COURT else CourtSection.DISTRICT_COURT
    }

    private fun cleanText(text: String): String =
        text.replace("\\s+".toRegex(), " ").trim().trimEnd('.', ' ')

    private fun parseDate(raw: String): String {
        val s = raw.trim()
        if (s.isBlank() || s.equals("null", ignoreCase = true) || s.equals("none", ignoreCase = true)
            || s == "0000-00-00" || s == "5000-01-01") return ""
        return DateUtils.parseAnyDate(s)
    }

    private fun cleanPartyName(raw: String): String {
        val cleaned = cleanText(raw)
        if (cleaned.isBlank()) return ""
        val lettersOnly = cleaned.replace("[^A-Za-z]".toRegex(), "")
        if (lettersOnly.isNotBlank() && lettersOnly.all { it.equals('X', ignoreCase = true) }) return ""
        return cleaned
    }

    fun normalize(obj: JSONObject): NormalizedEcourtsCase? {
        val cino = obj.optString("cino").ifBlank { obj.optString("cnr") }.trim()
        if (cino.isBlank()) return null

        val typeName = obj.optString("type_name").ifBlank { obj.optString("case_type") }.trim()
        val regNo = obj.optString("reg_no")
        val regYear = obj.optString("reg_year")
        val caseNo = if (regNo.isNotBlank() && regYear.isNotBlank()) {
            "$typeName/$regNo/$regYear"
        } else {
            obj.optString("case_no").ifBlank { cino }
        }

        val pet = cleanPartyName(obj.optString("petparty_name").ifBlank { obj.optString("pet_name") })
        val res = cleanPartyName(obj.optString("resparty_name").ifBlank { obj.optString("res_name") })
        val title = when {
            pet.isNotBlank() && res.isNotBlank() -> "$pet vs $res"
            pet.isNotBlank() -> pet
            res.isNotBlank() -> res
            else -> obj.optString("title").ifBlank { "Name withheld" }
        }

        var status = "Pending"
        val rawStatus = obj.optString("case_status").ifBlank { obj.optString("status") }.trim()
        if (rawStatus.equals("disposed", true) || rawStatus.equals("decided", true) || rawStatus.equals("closed", true)) {
            status = "Disposed"
        }

        val nextHearing = parseDate(obj.optString("date_next_list").ifBlank { obj.optString("next_hearing") })
        val disposalDate = parseDate(obj.optString("date_of_decision").ifBlank { obj.optString("disposal_date") })
        val filingDate = parseDate(obj.optString("filing_date").ifBlank { obj.optString("reg_date") })
        val vpDate = parseDate(obj.optString("vp_date"))

        val notesList = mutableListOf<String>()
        val purpose = obj.optString("purpose_name").ifBlank { obj.optString("purpose") }
        if (purpose.isNotBlank()) notesList.add("Purpose: $purpose")
        val disp = obj.optString("disp_name")
        if (disp.isNotBlank()) notesList.add("eCourts result: $disp")
        val note = cleanPartyName(obj.optString("note"))
        if (note.isNotBlank()) notesList.add(note)

        val district = cleanText(obj.optString("district_name").ifBlank { obj.optString("district") })
        val court = cleanText(obj.optString("establishment_name").ifBlank { obj.optString("court_name") })
        val bench = cleanText(obj.optString("court_no_desg_name").ifBlank { obj.optString("bench_name") })

        return NormalizedEcourtsCase(
            cino = cino,
            caseNo = caseNo,
            title = title,
            district = district,
            court = court,
            caseType = typeName,
            oppositeParty = res,
            status = status,
            nextHearing = nextHearing,
            disposalDate = disposalDate,
            filingDate = filingDate,
            vpDate = vpDate,
            notes = notesList.joinToString("\n"),
            bench = bench,
            appearingFor = obj.optString("appearing_for"),
            respondentNo = obj.optString("respondent_no"),
            rawJson = obj.toString()
        )
    }
}
