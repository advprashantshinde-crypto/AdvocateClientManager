package com.advocate.clientmanager.ui.navigation

import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.*
import androidx.navigation.compose.*
import com.advocate.clientmanager.AdvocateApp
import com.advocate.clientmanager.ui.screens.*
import com.advocate.clientmanager.util.CourtSection

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object AddClient : Screen("add_client")
    object EditClient : Screen("edit_client/{clientId}") {
        fun createRoute(clientId: Long) = "edit_client/$clientId"
    }
    object AddCase : Screen("add_case/{clientId}") {
        fun createRoute(clientId: Long) = "add_case/$clientId"
    }
    object EditCase : Screen("edit_case/{caseId}") {
        fun createRoute(caseId: Long) = "edit_case/$caseId"
    }
    object CaseDetail : Screen("case_detail/{caseId}") {
        fun createRoute(caseId: Long) = "case_detail/$caseId"
    }
    object Hearings : Screen("hearings")
    object Calendar : Screen("calendar")
    object Fees : Screen("fees/{clientId}") {
        fun createRoute(clientId: Long) = "fees/$clientId"
    }
    object PaymentRegister : Screen("payment_register/{caseId}") {
        fun createRoute(caseId: Long) = "payment_register/$caseId"
    }
    object Proceedings : Screen("proceedings/{caseId}") {
        fun createRoute(caseId: Long) = "proceedings/$caseId"
    }
    object Settings : Screen("settings")
    object MatterTypes : Screen("matter_types")
    object EcourtsImport : Screen("ecourts_import")
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val app = context.applicationContext as AdvocateApp
    var currentSection by remember { mutableStateOf(CourtSection.HIGH_COURT) }

    val repo = remember(currentSection) {
        when (currentSection) {
            CourtSection.HIGH_COURT -> app.highCourtRepo
            CourtSection.DISTRICT_COURT -> app.districtCourtRepo
        }
    }

    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(
                navController = navController,
                repo = repo,
                currentSection = currentSection,
                onSectionChange = { currentSection = it }
            )
        }
        composable(Screen.AddClient.route) {
            AddEditClientScreen(navController = navController, repo = repo, clientId = null)
        }
        composable(
            Screen.EditClient.route,
            arguments = listOf(navArgument("clientId") { type = NavType.LongType })
        ) { backStackEntry ->
            val clientId = backStackEntry.arguments?.getLong("clientId") ?: return@composable
            AddEditClientScreen(navController = navController, repo = repo, clientId = clientId)
        }
        composable(
            Screen.AddCase.route,
            arguments = listOf(navArgument("clientId") { type = NavType.LongType })
        ) { backStackEntry ->
            val clientId = backStackEntry.arguments?.getLong("clientId") ?: return@composable
            AddEditCaseScreen(navController = navController, repo = repo, clientId = clientId, caseId = null, section = currentSection)
        }
        composable(
            Screen.EditCase.route,
            arguments = listOf(navArgument("caseId") { type = NavType.LongType })
        ) { backStackEntry ->
            val caseId = backStackEntry.arguments?.getLong("caseId") ?: return@composable
            AddEditCaseScreen(navController = navController, repo = repo, clientId = 0, caseId = caseId, section = currentSection)
        }
        composable(
            Screen.CaseDetail.route,
            arguments = listOf(navArgument("caseId") { type = NavType.LongType })
        ) { backStackEntry ->
            val caseId = backStackEntry.arguments?.getLong("caseId") ?: return@composable
            CaseDetailScreen(navController = navController, repo = repo, caseId = caseId)
        }
        composable(Screen.Hearings.route) {
            HearingsScreen(navController = navController, repo = repo, section = currentSection)
        }
        composable(Screen.Calendar.route) {
            CalendarScreen(navController = navController, repo = repo, section = currentSection)
        }
        composable(
            Screen.Fees.route,
            arguments = listOf(navArgument("clientId") { type = NavType.LongType })
        ) { backStackEntry ->
            val clientId = backStackEntry.arguments?.getLong("clientId") ?: return@composable
            FeesScreen(navController = navController, repo = repo, clientId = clientId)
        }
        composable(
            Screen.PaymentRegister.route,
            arguments = listOf(navArgument("caseId") { type = NavType.LongType })
        ) { backStackEntry ->
            val caseId = backStackEntry.arguments?.getLong("caseId") ?: return@composable
            PaymentRegisterScreen(navController = navController, repo = repo, caseId = caseId)
        }
        composable(
            Screen.Proceedings.route,
            arguments = listOf(navArgument("caseId") { type = NavType.LongType })
        ) { backStackEntry ->
            val caseId = backStackEntry.arguments?.getLong("caseId") ?: return@composable
            ProceedingsScreen(navController = navController, repo = repo, caseId = caseId, section = currentSection)
        }
        composable(Screen.Settings.route) {
            SettingsScreen(navController = navController, app = app, section = currentSection)
        }
        composable(Screen.MatterTypes.route) {
            MatterTypesScreen(navController = navController, repo = repo, section = currentSection)
        }
        composable(Screen.EcourtsImport.route) {
            EcourtsImportScreen(navController = navController, app = app, section = currentSection)
        }
    }
}
