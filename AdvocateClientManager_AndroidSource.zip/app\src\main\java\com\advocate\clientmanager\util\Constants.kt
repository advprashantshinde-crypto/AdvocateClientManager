package com.advocate.clientmanager.util

object Constants {
    val HIGH_COURT_MATTER_TYPES = listOf(
        "Civil Writ Petition", "Criminal Writ Petition", "Criminal Appeal",
        "Second Appeal", "Appeal from Order",
        "Criminal Application for Bail", "Anticipatory Bail"
    )

    val DISTRICT_COURT_MATTER_TYPES = listOf(
        "Regular Civil Suit", "Special Civil Suit", "Small Cause Suit",
        "Regular Darkhast", "Execution Application", "Miscellaneous Civil Application",
        "Civil Appeal", "Miscellaneous Civil Appeal", "Regular Civil Appeal",
        "Regular Criminal Case", "Summary Criminal Case", "Sessions Case",
        "Criminal Appeal", "Criminal Revision Application", "Bail Application",
        "Domestic Violence Application", "Hindu Marriage Petition", "M.A.C.P.",
        "Land Acquisition Reference", "Other"
    )

    val BENCHES = listOf("Single Bench", "Division Bench")
    val CASE_STATUSES = listOf("Pending", "Hearing", "Judgment Reserved", "Disposed", "Closed")
    val DONE_STATUSES = setOf("Disposed", "Closed")
    val APPEARING_FOR = listOf("", "Petitioner", "Respondent")

    val HIGH_COURT_PROCEEDING_STAGES = listOf(
        "For Admission", "For Orders", "Await Service", "Final Hearing",
        "For W.S.", "Filing Reply", "For Hearing", "For Say", "For Rejoinder",
        "For Evidence", "For Cross-examination", "For Arguments",
        "For Compliance", "For Mentioning", "Other"
    )

    val DISTRICT_PROCEEDING_STAGES = listOf(
        "For W.S.", "Filing Reply", "For Hearing", "For Say", "For Rejoinder",
        "For Evidence", "For Cross-examination", "For Arguments", "For Orders",
        "For Compliance", "For Mentioning", "Other"
    )
}

enum class CourtSection(val displayName: String) {
    HIGH_COURT("High Court"),
    DISTRICT_COURT("District Court");

    companion object {
        fun fromDisplayName(name: String): CourtSection =
            entries.firstOrNull { it.displayName == name } ?: HIGH_COURT
    }
}
