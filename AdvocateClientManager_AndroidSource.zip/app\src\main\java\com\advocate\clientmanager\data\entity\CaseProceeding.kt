package com.advocate.clientmanager.data.entity

import androidx.room.*

@Entity(
    tableName = "case_proceedings",
    foreignKeys = [ForeignKey(entity = Case::class, parentColumns = ["id"], childColumns = ["case_id"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("case_id")]
)
data class CaseProceeding(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "case_id") val caseId: Long,
    @ColumnInfo(name = "proceeding_date") val proceedingDate: String,
    val stage: String,
    val remarks: String = ""
)
