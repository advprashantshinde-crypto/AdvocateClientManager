package com.advocate.clientmanager.data

import android.content.Context
import androidx.room.*
import com.advocate.clientmanager.data.dao.*
import com.advocate.clientmanager.data.entity.*

@Database(
    entities = [
        Client::class, Case::class, CasePayment::class, CaseProceeding::class,
        MatterType::class, DeletedCase::class, EcourtsImportState::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun clientDao(): ClientDao
    abstract fun caseDao(): CaseDao
    abstract fun paymentDao(): PaymentDao
    abstract fun proceedingDao(): ProceedingDao
    abstract fun matterTypeDao(): MatterTypeDao
    abstract fun deletedCaseDao(): DeletedCaseDao
    abstract fun ecourtsDao(): EcourtsDao

    companion object {
        @Volatile private var highCourtInstance: AppDatabase? = null
        @Volatile private var districtCourtInstance: AppDatabase? = null

        fun getHighCourtDatabase(context: Context): AppDatabase {
            return highCourtInstance ?: synchronized(this) {
                highCourtInstance ?: Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "high_court_clients.db"
                ).fallbackToDestructiveMigration().build().also { highCourtInstance = it }
            }
        }

        fun getDistrictCourtDatabase(context: Context): AppDatabase {
            return districtCourtInstance ?: synchronized(this) {
                districtCourtInstance ?: Room.databaseBuilder(
                    context.applicationContext, AppDatabase::class.java, "district_court_clients.db"
                ).fallbackToDestructiveMigration().build().also { districtCourtInstance = it }
            }
        }
    }
}
