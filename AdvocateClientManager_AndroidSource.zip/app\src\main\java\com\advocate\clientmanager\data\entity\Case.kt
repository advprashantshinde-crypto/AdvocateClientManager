package com.advocate.clientmanager.data.entity

import androidx.room.*

@Entity(
    tableName = "cases",
    foreignKeys = [ForeignKey(entity = Client::class, parentColumns = ["id"], childColumns = ["client_id"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("client_id"), Index("next_hearing"), Index("external_cino")]
)
data class Case(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "client_id") val clientId: Long,
    @ColumnInfo(name = "case_no") val caseNo: String = "",
    val title: String = "",
    val district: String = "",
    val court: String = "",
    @ColumnInfo(name = "case_type") val caseType: String = "",
    @ColumnInfo(name = "opposite_party") val oppositeParty: String = "",
    val status: String = "Pending",
    @ColumnInfo(name = "next_hearing") val nextHearing: String = "",
    @ColumnInfo(name = "disposal_date") val disposalDate: String = "",
    @ColumnInfo(name = "fees_agreed") val feesAgreed: Double = 0.0,
    val expenses: Double = 0.0,
    @ColumnInfo(name = "fees_paid") val feesPaid: Double = 0.0,
    val notes: String = "",
    val bench: String = "",
    @ColumnInfo(name = "appearing_for") val appearingFor: String = "",
    @ColumnInfo(name = "respondent_no") val respondentNo: String = "",
    @ColumnInfo(name = "filing_date") val filingDate: String = "",
    @ColumnInfo(name = "vp_date") val vpDate: String = "",
    @ColumnInfo(name = "external_cino") val externalCino: String = "",
    @ColumnInfo(name = "restored_after_delete") val restoredAfterDelete: Int = 0
) {
    fun appearingText(): String {
        return if (appearingFor.equals("Respondent", ignoreCase = true) && respondentNo.isNotBlank()) {
            "Respondent No. $respondentNo"
        } else {
            appearingFor
        }
    }

    fun benchCourtText(): String {
        val b = bench.trim()
        val c = court.trim()
        return if (b.isNotBlank() && c.isNotBlank()) "$b — $c" else b.ifBlank { c }
    }
}
