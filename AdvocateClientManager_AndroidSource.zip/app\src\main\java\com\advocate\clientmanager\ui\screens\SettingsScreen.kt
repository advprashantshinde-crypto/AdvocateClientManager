package com.advocate.clientmanager.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.advocate.clientmanager.AdvocateApp
import com.advocate.clientmanager.ui.components.AppTopBar
import com.advocate.clientmanager.ui.navigation.Screen
import com.advocate.clientmanager.ui.theme.*
import com.advocate.clientmanager.util.BackupManager
import com.advocate.clientmanager.util.Constants
import com.advocate.clientmanager.util.CourtSection
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@Composable
fun SettingsScreen(
    navController: NavController,
    app: AdvocateApp,
    section: CourtSection
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showResetDialog by remember { mutableStateOf(false) }
    var resetConfirmationInput by remember { mutableStateOf("") }
    var resetError by remember { mutableStateOf(false) }

    val expectedResetPhrase = remember(section) {
        if (section == CourtSection.HIGH_COURT) "RESET HIGH COURT" else "RESET DISTRICT COURT"
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val tempFile = File(context.cacheDir, "restore_temp.zip")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { output -> input.copyTo(output) }
                    }
                    val ok = BackupManager.restoreBackupZip(context, tempFile)
                    if (ok) {
                        Toast.makeText(context, "Backup restored successfully!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Could not restore backup", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(context, "Restore failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "App Settings",
                onBack = { navController.popBackStack() }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Cream)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Matter Types Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MATTER TYPES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Muted)
                    Text("High Court and District Court matter types are maintained separately.", fontSize = 12.sp, color = Ink)
                    Button(
                        onClick = { navController.navigate(Screen.MatterTypes.route) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent)
                    ) {
                        Text("Manage ${section.displayName} Matter Types")
                    }
                }
            }

            // eCourts Import Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ECOURTS IMPORT", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Muted)
                    Text("Import My Cases export (.txt or .json) from eCourts app / portal to sync hearing dates or add new matters.", fontSize = 12.sp, color = Ink)
                    OutlinedButton(
                        onClick = { navController.navigate("ecourts_import") },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Import eCourts File")
                    }
                }
            }

            // Backup & Restore Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("BACKUP & RESTORE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Muted)
                    Text("Create a ZIP backup containing both High Court and District Court databases, or restore from a previous backup.", fontSize = 12.sp, color = Ink)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val zip = BackupManager.createBackupZip(context)
                                    BackupManager.shareBackup(context, zip)
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent)
                        ) {
                            Text("Create Backup")
                        }

                        OutlinedButton(
                            onClick = { filePickerLauncher.launch("application/zip") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Restore Backup")
                        }
                    }
                }
            }

            // Factory Reset Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("FACTORY RESET", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DangerText)
                    Text(
                        "Clears all clients, cases, date-wise payments and proceeding history from the ${section.displayName} database. The other court database is not changed.",
                        fontSize = 12.sp,
                        color = Ink
                    )
                    Button(
                        onClick = {
                            resetConfirmationInput = ""
                            resetError = false
                            showResetDialog = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = DangerText)
                    ) {
                        Text("Factory Reset – ${section.displayName}")
                    }
                }
            }
        }
    }

    if (showResetDialog) {
        val repo = if (section == CourtSection.HIGH_COURT) app.highCourtRepo else app.districtCourtRepo
        val defaults = if (section == CourtSection.HIGH_COURT) Constants.HIGH_COURT_MATTER_TYPES else Constants.DISTRICT_COURT_MATTER_TYPES

        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Confirm Factory Reset") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "This will permanently erase all data in ${section.displayName}. Type '$expectedResetPhrase' below to confirm:",
                        fontSize = 12.sp,
                        color = DangerText
                    )
                    OutlinedTextField(
                        value = resetConfirmationInput,
                        onValueChange = {
                            resetConfirmationInput = it
                            resetError = false
                        },
                        label = { Text("Type confirmation phrase") },
                        isError = resetError,
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (resetConfirmationInput.trim() == expectedResetPhrase) {
                            coroutineScope.launch {
                                repo.factoryReset(defaults)
                                showResetDialog = false
                                Toast.makeText(context, "${section.displayName} database was reset.", Toast.LENGTH_LONG).show()
                                navController.popBackStack()
                            }
                        } else {
                            resetError = true
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = DangerText)
                ) {
                    Text("Confirm Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            }
        )
    }
}
