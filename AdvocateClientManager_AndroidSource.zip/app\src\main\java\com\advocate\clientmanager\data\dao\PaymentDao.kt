package com.advocate.clientmanager.data.dao

import androidx.room.*
import com.advocate.clientmanager.data.entity.CasePayment
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentDao {
    @Query("SELECT * FROM case_payments WHERE case_id = :caseId ORDER BY CASE WHEN payment_date = 'Previously recorded' THEN 0 ELSE 1 END, payment_date DESC, id DESC")
    fun getPaymentsForCase(caseId: Long): Flow<List<CasePayment>>

    @Query("SELECT * FROM case_payments WHERE id = :id")
    suspend fun getPaymentById(id: Long): CasePayment?

    @Query("SELECT COALESCE(SUM(amount), 0) FROM case_payments WHERE case_id = :caseId")
    suspend fun getTotalPaid(caseId: Long): Double

    @Query("SELECT * FROM case_payments WHERE case_id = :caseId ORDER BY payment_date, id")
    suspend fun getPaymentsForCaseList(caseId: Long): List<CasePayment>

    @Insert
    suspend fun insert(payment: CasePayment): Long

    @Update
    suspend fun update(payment: CasePayment)

    @Query("DELETE FROM case_payments WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM case_payments WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("DELETE FROM case_payments WHERE case_id = :caseId")
    suspend fun deleteAllForCase(caseId: Long)

    @Query("DELETE FROM case_payments")
    suspend fun clearAll()
}
