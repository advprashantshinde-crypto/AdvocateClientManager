package com.advocate.clientmanager

import android.app.Application
import com.advocate.clientmanager.data.AppDatabase
import com.advocate.clientmanager.data.entity.MatterType
import com.advocate.clientmanager.data.repository.AppRepository
import com.advocate.clientmanager.util.Constants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AdvocateApp : Application() {
    val highCourtDb by lazy { AppDatabase.getHighCourtDatabase(this) }
    val districtCourtDb by lazy { AppDatabase.getDistrictCourtDatabase(this) }

    val highCourtRepo by lazy { AppRepository(highCourtDb) }
    val districtCourtRepo by lazy { AppRepository(districtCourtDb) }

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        appScope.launch { seedMatterTypes() }
    }

    private suspend fun seedMatterTypes() {
        highCourtRepo.insertAllMatterTypes(
            Constants.HIGH_COURT_MATTER_TYPES.map { MatterType(it) }
        )
        districtCourtRepo.insertAllMatterTypes(
            Constants.DISTRICT_COURT_MATTER_TYPES.map { MatterType(it) }
        )
    }
}
